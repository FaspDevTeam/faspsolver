var structiBLCmat =
[
    [ "bcol", "structiBLCmat.html#aa72f0e4b562f9818797596099fb8ac41", null ],
    [ "blocks", "structiBLCmat.html#a8cea7044158e2bbc32709339144ab0cf", null ],
    [ "brow", "structiBLCmat.html#a0c327386c4e9c982b15bcc8726a16dd6", null ]
];