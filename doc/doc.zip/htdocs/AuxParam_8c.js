var AuxParam_8c =
[
    [ "fasp_param_amg_init", "AuxParam_8c.html#adb2bb76d2703d67ed1f87e2e265d14d5", null ],
    [ "fasp_param_amg_print", "AuxParam_8c.html#acc9e2a51b1516acb20e56463900ecef6", null ],
    [ "fasp_param_amg_set", "AuxParam_8c.html#a5d39ec25aa35fd5619e133031c625de7", null ],
    [ "fasp_param_amg_to_prec", "AuxParam_8c.html#a3fe5e9f8e4ceab5f804f0a7379cd8eee", null ],
    [ "fasp_param_amg_to_prec_bsr", "AuxParam_8c.html#a13f5bb1e234162b8b7e34b9a2db23ae8", null ],
    [ "fasp_param_ilu_init", "AuxParam_8c.html#a0b80baf5417c64f0c4d1cab2c8b63032", null ],
    [ "fasp_param_ilu_print", "AuxParam_8c.html#aed319ec015f812d4ffe6f93eb91376f9", null ],
    [ "fasp_param_ilu_set", "AuxParam_8c.html#aaf99789cd73622a777a4860a39664e5c", null ],
    [ "fasp_param_init", "AuxParam_8c.html#a88f296cc21ec17c7b5be273a71aaf7af", null ],
    [ "fasp_param_input_init", "AuxParam_8c.html#ac3a09f33ff50c2fa2dca7ef6edb9d5af", null ],
    [ "fasp_param_prec_to_amg", "AuxParam_8c.html#aeecc7aa30e0afa9044fdd83b400f2365", null ],
    [ "fasp_param_prec_to_amg_bsr", "AuxParam_8c.html#a0eaee029b6db825f5511971efa1e4f66", null ],
    [ "fasp_param_schwarz_init", "AuxParam_8c.html#a20fc8e5b9197d7a2d00119217eb61cf3", null ],
    [ "fasp_param_schwarz_print", "AuxParam_8c.html#a06e46b96ce326486f89eda93ea2f29f0", null ],
    [ "fasp_param_schwarz_set", "AuxParam_8c.html#a3f1aed4d43829c9043af7b830dd7f3a0", null ],
    [ "fasp_param_set", "AuxParam_8c.html#af1e5b162e629f0be9037b8864f4d927a", null ],
    [ "fasp_param_solver_init", "AuxParam_8c.html#a1f9f1f379a5a8d007765ae3360e2d83f", null ],
    [ "fasp_param_solver_print", "AuxParam_8c.html#af23f95a1d9d7893b10828d81fcf1b576", null ],
    [ "fasp_param_solver_set", "AuxParam_8c.html#adbb43a53f5c55345874d917006f793e1", null ]
];