var AuxParam_8c =
[
    [ "fasp_param_amg_init", "AuxParam_8c.html#adb2bb76d2703d67ed1f87e2e265d14d5", null ],
    [ "fasp_param_amg_print", "AuxParam_8c.html#acc9e2a51b1516acb20e56463900ecef6", null ],
    [ "fasp_param_amg_set", "AuxParam_8c.html#a5d39ec25aa35fd5619e133031c625de7", null ],
    [ "fasp_param_amg_to_prec", "AuxParam_8c.html#a3fe5e9f8e4ceab5f804f0a7379cd8eee", null ],
    [ "fasp_param_amg_to_precbsr", "AuxParam_8c.html#a5fd4171cddcf447f1b9ba65601e94bb9", null ],
    [ "fasp_param_ilu_init", "AuxParam_8c.html#a0b80baf5417c64f0c4d1cab2c8b63032", null ],
    [ "fasp_param_ilu_print", "AuxParam_8c.html#aed319ec015f812d4ffe6f93eb91376f9", null ],
    [ "fasp_param_ilu_set", "AuxParam_8c.html#aaf99789cd73622a777a4860a39664e5c", null ],
    [ "fasp_param_init", "AuxParam_8c.html#a2dcb35f56a8db32c9668dd58800fc44f", null ],
    [ "fasp_param_input_init", "AuxParam_8c.html#ac3a09f33ff50c2fa2dca7ef6edb9d5af", null ],
    [ "fasp_param_prec_to_amg", "AuxParam_8c.html#aeecc7aa30e0afa9044fdd83b400f2365", null ],
    [ "fasp_param_precbsr_to_amg", "AuxParam_8c.html#a5b0bd46eab8892b032c981b777617152", null ],
    [ "fasp_param_set", "AuxParam_8c.html#af1e5b162e629f0be9037b8864f4d927a", null ],
    [ "fasp_param_solver_init", "AuxParam_8c.html#ad5dfa3f81f2460b00b89b387658db182", null ],
    [ "fasp_param_solver_print", "AuxParam_8c.html#a978b6037e4903dfe9c2049ba36cb6a5a", null ],
    [ "fasp_param_solver_set", "AuxParam_8c.html#affc1f13e8c53ef0bb61199c7d3999c5e", null ],
    [ "fasp_param_swz_init", "AuxParam_8c.html#a7a8865ac245229725cdd0cc30d21f9d1", null ],
    [ "fasp_param_swz_print", "AuxParam_8c.html#aef9d2d6da6b4ec91350280858b82a639", null ],
    [ "fasp_param_swz_set", "AuxParam_8c.html#aa5aed34f842727e86f7e408f007c41bf", null ]
];