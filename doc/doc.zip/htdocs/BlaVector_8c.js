var BlaVector_8c =
[
    [ "fasp_blas_dvec_axpy", "BlaVector_8c.html#a12707ae8d7435fb22fd4a8cd2d66e687", null ],
    [ "fasp_blas_dvec_axpyz", "BlaVector_8c.html#abaceb436282c834b623454b0d11bfa3c", null ],
    [ "fasp_blas_dvec_dotprod", "BlaVector_8c.html#a491c0ac08b069cb0fb2f171896d77536", null ],
    [ "fasp_blas_dvec_norm1", "BlaVector_8c.html#af5a3b2e1aec36ba2077a51f63c597c33", null ],
    [ "fasp_blas_dvec_norm2", "BlaVector_8c.html#a1eed83b61b83be2792944ac24de3ecda", null ],
    [ "fasp_blas_dvec_norminf", "BlaVector_8c.html#ae869345cb67762963dfce9e94f0330ce", null ],
    [ "fasp_blas_dvec_relerr", "BlaVector_8c.html#accd37d6f1b5a0375901c3ad643d89f9b", null ]
];