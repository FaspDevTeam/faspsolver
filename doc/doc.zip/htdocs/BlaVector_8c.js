var BlaVector_8c =
[
    [ "fasp_blas_dvec_axpy", "BlaVector_8c.html#a184fb097272820aa3becf22efd9dfaf2", null ],
    [ "fasp_blas_dvec_axpyz", "BlaVector_8c.html#a2f183ea758c3f921209a5543fd9d092a", null ],
    [ "fasp_blas_dvec_dotprod", "BlaVector_8c.html#adf369aba1a4bcaaafe5d36edb5a5e2ef", null ],
    [ "fasp_blas_dvec_norm1", "BlaVector_8c.html#a9cacc3cc6bedb69f16dcd427a9473ad5", null ],
    [ "fasp_blas_dvec_norm2", "BlaVector_8c.html#af12ab71dbda8b808bc5912ce255f1a67", null ],
    [ "fasp_blas_dvec_norminf", "BlaVector_8c.html#a68bddbbb1d0eea53f921855fa684591e", null ],
    [ "fasp_blas_dvec_relerr", "BlaVector_8c.html#ad6c406ddea685b2dfcca9f17cff53f7c", null ]
];