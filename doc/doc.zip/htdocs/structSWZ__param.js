var structSWZ__param =
[
    [ "print_level", "structSWZ__param.html#a29a57f89daa78e58e74d262209e9cf77", null ],
    [ "SWZ_blksolver", "structSWZ__param.html#a927c26896fe9fe9ff5b3cf89a8f53171", null ],
    [ "SWZ_maxlvl", "structSWZ__param.html#a2f126ee21f35fb9dfbed519c9e3514f3", null ],
    [ "SWZ_mmsize", "structSWZ__param.html#a20b7a36aed4582605e1a61f2a8c99510", null ],
    [ "SWZ_type", "structSWZ__param.html#aa5a67cec7d7f2064b5d24f97beb5a1f3", null ]
];