var structprecond__block__data =
[
    [ "A_diag", "structprecond__block__data.html#a5a9cc362638a4f681b93ac827bbff194", null ],
    [ "Ablc", "structprecond__block__data.html#a184f2c20c7c5d571440215db45fdc948", null ],
    [ "amgparam", "structprecond__block__data.html#a9b7f8b5eb6381d02223915a1987e1a58", null ],
    [ "LU_diag", "structprecond__block__data.html#a96067b2c21e261562feaad69d2c0c800", null ],
    [ "mgl", "structprecond__block__data.html#a86e6851254ff0a1314cbe05be78e7abf", null ],
    [ "r", "structprecond__block__data.html#afc193e8972f36a0f5c4e134825ace77f", null ]
];