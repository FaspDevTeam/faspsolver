var NAVTREE =
[
  [ "Fast Auxiliary Space Preconditioning", "index.html", [
    [ "Introduction", "index.html", null ],
    [ "How to obtain FASP", "download.html", null ],
    [ "Building and Installation", "build.html", null ],
    [ "Developers", "developers.html", null ],
    [ "Doxygen", "doxygen_comment.html", null ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"amg_8c.html",
"fasp__const_8h.html#a131b3ce119829a4ffbfdca3da08d0766",
"ilu__setup__csr_8c.html#abfc6cc3b180f699a1fb7c22e706fb4ba",
"precond__bsr_8c.html#a2c8ad271e990d7f700fa78e4b926a120",
"structAMG__data.html#a768df12bab35f908514f8e37ee02d8cf",
"structinput__param.html#a42173fdfb24716e25d268e61897f237c",
"threads_8c.html#a0583cea98df27c80d50dc814eca861d3"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';