var NAVTREE =
[
  [ "Fast Auxiliary Space Preconditioning", "index.html", [
    [ "Introduction", "index.html", null ],
    [ "How to obtain FASP", "download.html", null ],
    [ "Building and Installation", "build.html", null ],
    [ "Developers", "developers.html", null ],
    [ "Doxygen", "doxygen_comment.html", null ],
    [ "Todo List", "todo.html", null ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"amg_8c.html",
"fasp__const_8h.html#a18acdce401ee0e52073166b285b3c56e",
"init_8c.html#ab10ae5b0b47f43946dba4d039dc6e95d",
"precond__csr_8c.html#a7b183b976330ee81c61ce3ceb2ffe3b6",
"structAMG__data.html#ac7f8740ade9a83cb649a880d329cbcf8",
"structinput__param.html#a7044093a2d23cdf8a89ee28685850ff3",
"todo.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';