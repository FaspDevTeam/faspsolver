var NAVTREE =
[
  [ "Fast Auxiliary Space Preconditioning", "index.html", [
    [ "Introduction", "index.html", null ],
    [ "How to obtain FASP", "download.html", null ],
    [ "Building and Installation", "build.html", null ],
    [ "Developers", "developers.html", null ],
    [ "Doxygen", "doxygen_comment.html", null ],
    [ "Todo List", "todo.html", null ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"amg_8c.html",
"fasp__const_8h.html#a1471ce2089f610da213ba6a2ec2879e6",
"init_8c.html#a555685e232ca09a4f115e42a9eaa0841",
"precond__csr_8c.html",
"structAMG__data.html#a9f548e9035a7178e3a90f2abf796523b",
"structinput__param.html#a631f17b0f721db52851e1194a0c50403",
"structprecond__data__bsr.html#a6cce76f0e6bd8083e9fc49bf92705acd"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';