var NAVTREE =
[
  [ "Fast Auxiliary Space Preconditioning", "index.html", [
    [ "Introduction", "index.html", null ],
    [ "How to obtain FASP", "download.html", null ],
    [ "Building and Installation", "build.html", null ],
    [ "Developers", "developers.html", null ],
    [ "Doxygen", "doxygen_comment.html", null ],
    [ "Data Structures", null, [
      [ "Data Structures", "annotated.html", "annotated" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"amg_8c.html",
"fasp__const_8h.html#a131b3ce119829a4ffbfdca3da08d0766",
"init_8c.html#a18ae248a526c0a5ecd395ef3b852fc4a",
"precond__csr_8c.html#a43f7b8e862efe4c6234ca46feb314724",
"spvgmres_8c.html#ac24bc0ce878eff5ff91f8c92e35d6ade",
"structinput__param.html#a29a57f89daa78e58e74d262209e9cf77",
"structprecond__sweeping__data.html#a83b9edd1947df16c603ce6b5d050ba4f"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';