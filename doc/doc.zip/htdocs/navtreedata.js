var NAVTREE =
[
  [ "Fast Auxiliary Space Preconditioning", "index.html", [
    [ "Introduction", "index.html", null ],
    [ "How to obtain FASP", "download.html", null ],
    [ "Building and Installation", "build.html", null ],
    [ "Developers", "developers.html", null ],
    [ "Doxygen", "doxygen_comment.html", null ],
    [ "Todo List", "todo.html", null ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"AuxArray_8c.html",
"BlaSmallMat_8c.html#aa80a8cac4dcc3b57cee5b7c73b8e4445",
"KryPgcr_8c.html#ab9acabe62bef34b1caa961501970bb79",
"fasp_8h.html#a0be6e67f9bf3b77811c280f8a81f5a2f",
"globals_f.html",
"structgrid2d.html#af4f9883eb2c15154302574c00a8fa343",
"structprecond__diagbsr.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';