var BlaArray_8c =
[
    [ "fasp_blas_array_ax", "BlaArray_8c.html#ad74c1b2368e5b30b3c510f7b79b16861", null ],
    [ "fasp_blas_array_axpby", "BlaArray_8c.html#a761449fd069214676d351782a302eade", null ],
    [ "fasp_blas_array_axpy", "BlaArray_8c.html#a3c77aa5befd3b4161c96ea79857a5ccd", null ],
    [ "fasp_blas_array_axpyz", "BlaArray_8c.html#a18d0ccf89b245fc1a206fbcf73eee932", null ],
    [ "fasp_blas_array_dotprod", "BlaArray_8c.html#a81f4c3be7b67a6f0d3184b3b1043e361", null ],
    [ "fasp_blas_array_norm1", "BlaArray_8c.html#ac4dee4f2f6d9c76a552393beddc60b57", null ],
    [ "fasp_blas_array_norm2", "BlaArray_8c.html#ab9e92b6742774d4049be41f099af7006", null ],
    [ "fasp_blas_array_norminf", "BlaArray_8c.html#ab847583de17802992467caaa464b822e", null ]
];