var BlaArray_8c =
[
    [ "fasp_blas_array_ax", "BlaArray_8c.html#ad74c1b2368e5b30b3c510f7b79b16861", null ],
    [ "fasp_blas_array_axpby", "BlaArray_8c.html#a932cb6d4f4a512654f297ba1fd2f8998", null ],
    [ "fasp_blas_array_axpy", "BlaArray_8c.html#a50c1bb8e42138b5ec149c0e9b32c1588", null ],
    [ "fasp_blas_array_axpyz", "BlaArray_8c.html#a7e4cdd7f008b401e94e5fdb50f948d19", null ],
    [ "fasp_blas_array_dotprod", "BlaArray_8c.html#a81f4c3be7b67a6f0d3184b3b1043e361", null ],
    [ "fasp_blas_array_norm1", "BlaArray_8c.html#ac4dee4f2f6d9c76a552393beddc60b57", null ],
    [ "fasp_blas_array_norm2", "BlaArray_8c.html#ab9e92b6742774d4049be41f099af7006", null ],
    [ "fasp_blas_array_norminf", "BlaArray_8c.html#ab847583de17802992467caaa464b822e", null ]
];