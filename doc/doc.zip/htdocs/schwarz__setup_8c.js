var schwarz__setup_8c =
[
    [ "fasp_dcsr_Schwarz_backward_smoother", "schwarz__setup_8c.html#a5b96c9258960c906c96349a653b5ca7d", null ],
    [ "fasp_dcsr_Schwarz_forward_smoother", "schwarz__setup_8c.html#a389696ac40cb7d1e298117632a457cbc", null ],
    [ "fasp_Schwarz_get_block_matrix", "schwarz__setup_8c.html#a73c59e0f929d5029a48a0dfea9f73cf7", null ],
    [ "fasp_Schwarz_setup", "schwarz__setup_8c.html#a682e0258beb79e3fe33a7876bad1d845", null ]
];