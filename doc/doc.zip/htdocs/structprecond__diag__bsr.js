var structprecond__diag__bsr =
[
    [ "diag", "structprecond__diag__bsr.html#aa2ab1984071b37d6300f7ddcc97c68de", null ],
    [ "nb", "structprecond__diag__bsr.html#a71f3d0d1b9013165b0616c75e14ecb5d", null ]
];