var BlaSpmvCSR_8c =
[
    [ "fasp_blas_dcsr_aAxpy", "BlaSpmvCSR_8c.html#adc1d674395b5962dd8614030245cf250", null ],
    [ "fasp_blas_dcsr_aAxpy_agg", "BlaSpmvCSR_8c.html#a6b0d06087c4d8ab22221f5b74de649e4", null ],
    [ "fasp_blas_dcsr_add", "BlaSpmvCSR_8c.html#a82b4d3aaa83c7b5794ac086509e0298a", null ],
    [ "fasp_blas_dcsr_axm", "BlaSpmvCSR_8c.html#a1a08e5abd54c3116f0e96bc30bcb3c75", null ],
    [ "fasp_blas_dcsr_bandwith", "BlaSpmvCSR_8c.html#a00a041de8d1d7b4a7b764dff3008787a", null ],
    [ "fasp_blas_dcsr_mxm", "BlaSpmvCSR_8c.html#ae8f6ca7a1375371fe82f89eee1d99cd6", null ],
    [ "fasp_blas_dcsr_mxv", "BlaSpmvCSR_8c.html#a6c4014769d71ccfec0d0c1403f66d5dd", null ],
    [ "fasp_blas_dcsr_mxv_agg", "BlaSpmvCSR_8c.html#a234d02652dfc0ce1f2bf6190a606ccfd", null ],
    [ "fasp_blas_dcsr_ptap", "BlaSpmvCSR_8c.html#aa4b53af39b12e2b0010365be0360f56e", null ],
    [ "fasp_blas_dcsr_rap", "BlaSpmvCSR_8c.html#a797155e28147b7368b5c23fd44c16267", null ],
    [ "fasp_blas_dcsr_rap2", "BlaSpmvCSR_8c.html#a30c7a38789c8f9755144e71a28848733", null ],
    [ "fasp_blas_dcsr_rap4", "BlaSpmvCSR_8c.html#a968dd3fdbc3ef21a1b7a3e86cfd807fa", null ],
    [ "fasp_blas_dcsr_rap_agg", "BlaSpmvCSR_8c.html#a2a3af13e115cf43c69f1a3e042fda509", null ],
    [ "fasp_blas_dcsr_rap_agg1", "BlaSpmvCSR_8c.html#aad76e8260874ceb8aa6a6f360a67a21f", null ],
    [ "fasp_blas_dcsr_vmv", "BlaSpmvCSR_8c.html#af08fec960e311973f4d5d64772698d30", null ]
];