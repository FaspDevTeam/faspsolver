var AuxMemory_8c =
[
    [ "fasp_mem_calloc", "AuxMemory_8c.html#a3120cd01ffcfbc84e9e5ade23c00a2a6", null ],
    [ "fasp_mem_check", "AuxMemory_8c.html#ab8ef862995c85ed86b9bc23050a4df1c", null ],
    [ "fasp_mem_free", "AuxMemory_8c.html#a1ec34a015326b359992c2424269cc048", null ],
    [ "fasp_mem_iludata_check", "AuxMemory_8c.html#a6deaf00a35d7f824a0e697b69f2245d8", null ],
    [ "fasp_mem_realloc", "AuxMemory_8c.html#aed3749fe78a05e6ab04edca99aad8116", null ],
    [ "fasp_mem_usage", "AuxMemory_8c.html#af00b5dac654acbf25a8d6895a6e9983f", null ],
    [ "Million", "AuxMemory_8c.html#a0c885651acd7763a76a1ebbefd9c4a50", null ],
    [ "total_alloc_count", "AuxMemory_8c.html#a8b14f3bf80619e4909f60d0a75b1b2c8", null ],
    [ "total_alloc_mem", "AuxMemory_8c.html#a790fccbaed2f636a73e45611e0c657c9", null ]
];