var AuxMemory_8c =
[
    [ "fasp_mem_calloc", "AuxMemory_8c.html#a3120cd01ffcfbc84e9e5ade23c00a2a6", null ],
    [ "fasp_mem_free", "AuxMemory_8c.html#a1ec34a015326b359992c2424269cc048", null ],
    [ "fasp_mem_iludata_check", "AuxMemory_8c.html#aeac88271fd0e33e254e1b72e698de520", null ],
    [ "fasp_mem_realloc", "AuxMemory_8c.html#aed3749fe78a05e6ab04edca99aad8116", null ],
    [ "fasp_mem_usage", "AuxMemory_8c.html#a743dfdd26adb578ae80c213945ef494c", null ],
    [ "Million", "AuxMemory_8c.html#a0c885651acd7763a76a1ebbefd9c4a50", null ],
    [ "total_alloc_count", "AuxMemory_8c.html#a8b14f3bf80619e4909f60d0a75b1b2c8", null ],
    [ "total_alloc_mem", "AuxMemory_8c.html#a790fccbaed2f636a73e45611e0c657c9", null ]
];