var init_8c =
[
    [ "fasp_amg_data_bsr_create", "init_8c.html#ac65fee742df3f05b202c282f0312da22", null ],
    [ "fasp_amg_data_create", "init_8c.html#ab10ae5b0b47f43946dba4d039dc6e95d", null ],
    [ "fasp_amg_data_free", "init_8c.html#ae527d40dcd87014c3e009632f44cdc9a", null ],
    [ "fasp_ilu_data_alloc", "init_8c.html#ac4a2782ca417b3eb4344296cf23023a0", null ],
    [ "fasp_ilu_data_free", "init_8c.html#a3a70004a78a8e0e3a1b89fe012455267", null ],
    [ "fasp_ilu_data_null", "init_8c.html#af0f7ea070acdc68a5b6d81f1bb3f2588", null ],
    [ "fasp_precond_null", "init_8c.html#ac93ac3cb78d77b17e46cce58c6236fc5", null ],
    [ "fasp_schwarz_data_free", "init_8c.html#a18ae248a526c0a5ecd395ef3b852fc4a", null ]
];