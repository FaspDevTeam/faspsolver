var init_8c =
[
    [ "fasp_amg_data_bsr_create", "init_8c.html#ac65fee742df3f05b202c282f0312da22", null ],
    [ "fasp_amg_data_bsr_free", "init_8c.html#aea50a26f18ee25960d7c54ae076f0cdd", null ],
    [ "fasp_amg_data_create", "init_8c.html#ab10ae5b0b47f43946dba4d039dc6e95d", null ],
    [ "fasp_amg_data_free", "init_8c.html#ac902870ef1bb2a00d270e48f389d1992", null ],
    [ "fasp_ilu_data_alloc", "init_8c.html#ac4a2782ca417b3eb4344296cf23023a0", null ],
    [ "fasp_ilu_data_free", "init_8c.html#a3a70004a78a8e0e3a1b89fe012455267", null ],
    [ "fasp_ilu_data_null", "init_8c.html#af0f7ea070acdc68a5b6d81f1bb3f2588", null ],
    [ "fasp_precond_data_null", "init_8c.html#a604934376a749e47c11fdeb75c41ff69", null ],
    [ "fasp_precond_null", "init_8c.html#ac93ac3cb78d77b17e46cce58c6236fc5", null ],
    [ "fasp_Schwarz_data_free", "init_8c.html#a18a07b980675f529af767b8aadbd0180", null ]
];