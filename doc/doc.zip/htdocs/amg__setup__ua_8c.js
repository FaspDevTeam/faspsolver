var amg__setup__ua_8c =
[
    [ "fasp_amg_setup_ua", "amg__setup__ua_8c.html#a83333c65f442155b2658f1b673cbcdea", null ],
    [ "fasp_amg_setup_ua_bsr", "amg__setup__ua_8c.html#a7246299524147a5909f7f8a7c3ae69be", null ]
];