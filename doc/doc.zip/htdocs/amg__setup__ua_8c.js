var amg__setup__ua_8c =
[
    [ "amg_setup_unsmoothP_unsmoothA", "amg__setup__ua_8c.html#a4f7a65da60a1e1cd04f623bd80a33129", null ],
    [ "amg_setup_unsmoothP_unsmoothA_bsr", "amg__setup__ua_8c.html#ae33bf71a15a383582b7acff160d095e2", null ],
    [ "fasp_amg_setup_ua", "amg__setup__ua_8c.html#a83333c65f442155b2658f1b673cbcdea", null ],
    [ "fasp_amg_setup_ua_bsr", "amg__setup__ua_8c.html#a7246299524147a5909f7f8a7c3ae69be", null ]
];