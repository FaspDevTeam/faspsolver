var PreMGRecurAMLI_8c =
[
    [ "fasp_amg_amli_coef", "PreMGRecurAMLI_8c.html#a449284186f1df5fc62c71118fc3b6b8c", null ],
    [ "fasp_solver_amli", "PreMGRecurAMLI_8c.html#a6169ca0315b9a9d61f0e9815f29f0d3f", null ],
    [ "fasp_solver_namli", "PreMGRecurAMLI_8c.html#a2396973120f6ac4fdd4a398985316f20", null ],
    [ "fasp_solver_namli_bsr", "PreMGRecurAMLI_8c.html#acce0533deeb87c0a793c755f58be8b17", null ]
];