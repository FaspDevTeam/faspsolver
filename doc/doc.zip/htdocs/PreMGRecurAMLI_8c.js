var PreMGRecurAMLI_8c =
[
    [ "fasp_amg_amli_coef", "PreMGRecurAMLI_8c.html#a449284186f1df5fc62c71118fc3b6b8c", null ],
    [ "fasp_solver_amli", "PreMGRecurAMLI_8c.html#a6169ca0315b9a9d61f0e9815f29f0d3f", null ],
    [ "fasp_solver_nl_amli", "PreMGRecurAMLI_8c.html#a409a5e44771911337c3d6ff934c27ca1", null ],
    [ "fasp_solver_nl_amli_bsr", "PreMGRecurAMLI_8c.html#a425dff581f5a4f6f9da2d9d5ba6e9c14", null ]
];