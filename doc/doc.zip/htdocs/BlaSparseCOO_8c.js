var BlaSparseCOO_8c =
[
    [ "fasp_dcoo_alloc", "BlaSparseCOO_8c.html#a32b57a192a99f48fcddf487b70b8d80a", null ],
    [ "fasp_dcoo_create", "BlaSparseCOO_8c.html#a5d833894a0c9e39de2d58f0d85cb85f6", null ],
    [ "fasp_dcoo_free", "BlaSparseCOO_8c.html#a14f7dea89658b429dcc667018d528d6b", null ],
    [ "fasp_dcoo_shift", "BlaSparseCOO_8c.html#ac644535d5bf0059e20cdc383482fbb1a", null ]
];