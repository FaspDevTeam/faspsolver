var coarsening__cr_8c =
[
    [ "fasp_amg_coarsening_cr", "coarsening__cr_8c.html#a88f4644d12f9e3e464a57431e5395a18", null ],
    [ "GraphAdd", "coarsening__cr_8c.html#aa607cea61a0ded6ad9d52952fca43e48", null ],
    [ "GraphRemove", "coarsening__cr_8c.html#a0a78e970c9804d7cbdbe596691ef5bbb", null ],
    [ "indset", "coarsening__cr_8c.html#ab434cd040cc346e83eb977874c5991b0", null ]
];