var AuxGraphics_8c =
[
    [ "fasp_dbsr_plot", "AuxGraphics_8c.html#a8bfbbe8ed9e8b575d6d9020b6d25c903", null ],
    [ "fasp_dbsr_subplot", "AuxGraphics_8c.html#aeefb5caa5ef59257cd872e4a7407231e", null ],
    [ "fasp_dcsr_plot", "AuxGraphics_8c.html#a872648bf713fcd4aca0b749ef563d347", null ],
    [ "fasp_dcsr_subplot", "AuxGraphics_8c.html#aebfd02a42d81bed57df150ecdc17ddcc", null ],
    [ "fasp_grid2d_plot", "AuxGraphics_8c.html#a745cc561f8bf7385bec78c7324d23b50", null ]
];