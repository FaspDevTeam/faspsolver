var AuxGraphics_8c =
[
    [ "fasp_dbsr_plot", "AuxGraphics_8c.html#a8bfbbe8ed9e8b575d6d9020b6d25c903", null ],
    [ "fasp_dbsr_subplot", "AuxGraphics_8c.html#a0d58e9c2653ccce15d2776cd04af9340", null ],
    [ "fasp_dcsr_plot", "AuxGraphics_8c.html#a872648bf713fcd4aca0b749ef563d347", null ],
    [ "fasp_dcsr_subplot", "AuxGraphics_8c.html#a79f7c69e622c1a40715ca577e9a7c5fe", null ],
    [ "fasp_grid2d_plot", "AuxGraphics_8c.html#a2275cdfa5d7b8acbca78ccb8273dc959", null ]
];