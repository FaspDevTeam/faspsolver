var structdCSRLmat =
[
    [ "col", "structdCSRLmat.html#a35e7c2cd24fb4171cce3d78cd8bb3a23", null ],
    [ "dif", "structdCSRLmat.html#abe359223493d44177442a883d5ae441e", null ],
    [ "index", "structdCSRLmat.html#aaa9d6e26c6c651a0eb57d5211717f6cf", null ],
    [ "ja", "structdCSRLmat.html#acd4cdbb6856b6bbc078b03702169fd2d", null ],
    [ "nnz", "structdCSRLmat.html#aa165c73f6701cd01aafc0868e6261dfe", null ],
    [ "nz_diff", "structdCSRLmat.html#ab04368e4d32ae75febebc143c14a721c", null ],
    [ "row", "structdCSRLmat.html#a741a152c7b18c401af249dfb3a113c95", null ],
    [ "start", "structdCSRLmat.html#a961281fc7401cc5573fa75d8ee0c123e", null ],
    [ "val", "structdCSRLmat.html#a6e543bb0c5acc1b10ba8e2a72eb92b52", null ]
];