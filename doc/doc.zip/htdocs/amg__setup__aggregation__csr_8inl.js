var amg__setup__aggregation__csr_8inl =
[
    [ "aggregation", "amg__setup__aggregation__csr_8inl.html#aa5d1546baca9d6ca3915389bf35ddd24", null ],
    [ "form_tentative_p", "amg__setup__aggregation__csr_8inl.html#a11701c06894f56b0de3b678c55bcf24f", null ]
];