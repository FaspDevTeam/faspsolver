var ItrSmootherBSR_8c =
[
    [ "fasp_smoother_dbsr_gs", "ItrSmootherBSR_8c.html#aaaa65622c1594000eec5f86d1600d52c", null ],
    [ "fasp_smoother_dbsr_gs1", "ItrSmootherBSR_8c.html#a32af28214de63517e7daedbaac31d827", null ],
    [ "fasp_smoother_dbsr_gs_ascend", "ItrSmootherBSR_8c.html#a658393053827ab0706195a02beb7d781", null ],
    [ "fasp_smoother_dbsr_gs_ascend1", "ItrSmootherBSR_8c.html#a794c1ea0e4a6f6f8e67ddc078cc2c075", null ],
    [ "fasp_smoother_dbsr_gs_descend", "ItrSmootherBSR_8c.html#a081b9e8441eaff309121c3e93598faf1", null ],
    [ "fasp_smoother_dbsr_gs_descend1", "ItrSmootherBSR_8c.html#a5ebafc1601925a86a8873350502c4fa4", null ],
    [ "fasp_smoother_dbsr_gs_order1", "ItrSmootherBSR_8c.html#af011690a31d63df3fa415989dbddfbc7", null ],
    [ "fasp_smoother_dbsr_gs_order2", "ItrSmootherBSR_8c.html#a50d5dd38663ca15594cd9833172358a1", null ],
    [ "fasp_smoother_dbsr_ilu", "ItrSmootherBSR_8c.html#a9394e55335b69173f5139a1c2978ac66", null ],
    [ "fasp_smoother_dbsr_jacobi", "ItrSmootherBSR_8c.html#aa034b187d68c479e7d5b658b1e031873", null ],
    [ "fasp_smoother_dbsr_jacobi1", "ItrSmootherBSR_8c.html#a63da822d5e1fb2c162d795ff67f7d13c", null ],
    [ "fasp_smoother_dbsr_jacobi_setup", "ItrSmootherBSR_8c.html#a487e3c4ae3c2c3c8ad3a05d77783cb2f", null ],
    [ "fasp_smoother_dbsr_sor", "ItrSmootherBSR_8c.html#afbd5ba13de4466c7144ee3bb7223bb56", null ],
    [ "fasp_smoother_dbsr_sor1", "ItrSmootherBSR_8c.html#ab924e23255e90bb84d23ffab3c2b437f", null ],
    [ "fasp_smoother_dbsr_sor_ascend", "ItrSmootherBSR_8c.html#a8d7bc1f7948b8a1cd4f8834798e455e7", null ],
    [ "fasp_smoother_dbsr_sor_descend", "ItrSmootherBSR_8c.html#adc883cf4c993892b02359ad5e5631ec8", null ],
    [ "fasp_smoother_dbsr_sor_order", "ItrSmootherBSR_8c.html#ac88cb3696d79a183c79e8999e8c6dbe1", null ],
    [ "ilu_solve_time", "ItrSmootherBSR_8c.html#ac62f139ad2a85358ed53f5fb45982441", null ]
];