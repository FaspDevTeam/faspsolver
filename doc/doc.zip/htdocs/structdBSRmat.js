var structdBSRmat =
[
    [ "COL", "structdBSRmat.html#a1e1aa4869c0ea26f78744da8d39c1751", null ],
    [ "IA", "structdBSRmat.html#a82a122cbfe1b4c4d010a147a0a72ebd1", null ],
    [ "JA", "structdBSRmat.html#ab39d8b2fa3fbf92c115fa73cb98bc7ce", null ],
    [ "nb", "structdBSRmat.html#a71f3d0d1b9013165b0616c75e14ecb5d", null ],
    [ "NNZ", "structdBSRmat.html#a2797c1f091b9f22182490bfcefccebd7", null ],
    [ "ROW", "structdBSRmat.html#a9b6281daf3209fc9d1c955400241465c", null ],
    [ "storage_manner", "structdBSRmat.html#ae7a5fca4952e68db0abe7ddb40a8e772", null ],
    [ "val", "structdBSRmat.html#a6e543bb0c5acc1b10ba8e2a72eb92b52", null ]
];