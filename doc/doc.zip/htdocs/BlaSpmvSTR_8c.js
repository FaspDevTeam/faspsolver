var BlaSpmvSTR_8c =
[
    [ "fasp_blas_dstr_aAxpy", "BlaSpmvSTR_8c.html#a196f206b82ae340edc75848b19482e7c", null ],
    [ "fasp_blas_dstr_mxv", "BlaSpmvSTR_8c.html#adc6cfe9c1d89fc5b25c07c60b06f5c03", null ],
    [ "fasp_dstr_diagscale", "BlaSpmvSTR_8c.html#a01d5383101bc7fb47e8fde778bd986df", null ]
];