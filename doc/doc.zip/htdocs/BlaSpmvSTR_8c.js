var BlaSpmvSTR_8c =
[
    [ "fasp_blas_dstr_aAxpy", "BlaSpmvSTR_8c.html#a9db9efd427f8328406869dfc5628b846", null ],
    [ "fasp_blas_dstr_mxv", "BlaSpmvSTR_8c.html#a26d41f2403d2cd9bc98f33ea60a5ab28", null ],
    [ "fasp_dstr_diagscale", "BlaSpmvSTR_8c.html#a41d2c7395d56cdbb55ac4cedbc94bc0f", null ]
];