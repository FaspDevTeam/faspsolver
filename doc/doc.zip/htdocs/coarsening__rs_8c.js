var coarsening__rs_8c =
[
    [ "LIST_HEAD", "coarsening__rs_8c.html#a5fc6a15ca26c6208f66ad2768a3108ef", null ],
    [ "LIST_TAIL", "coarsening__rs_8c.html#a745de98bef5b645df56479181803235b", null ],
    [ "enter_list", "coarsening__rs_8c.html#ae113ee796b4433d8d45696f5a361f037", null ],
    [ "fasp_amg_coarsening_rs", "coarsening__rs_8c.html#ac7c9fdc8a585185e9bf4d28ffba806f0", null ],
    [ "remove_node", "coarsening__rs_8c.html#afa0f583f356c9090e8842ede065b262b", null ]
];