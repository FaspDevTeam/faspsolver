var coarsening__rs_8c =
[
    [ "LIST_HEAD", "coarsening__rs_8c.html#a5fc6a15ca26c6208f66ad2768a3108ef", null ],
    [ "LIST_TAIL", "coarsening__rs_8c.html#a745de98bef5b645df56479181803235b", null ],
    [ "create_node", "coarsening__rs_8c.html#a1f4848f81a6ad1a905890677599f7d6e", null ],
    [ "dispose_node", "coarsening__rs_8c.html#ac5bafe3c53d0002830e7f6ed86ffa49e", null ],
    [ "enter_list", "coarsening__rs_8c.html#ae113ee796b4433d8d45696f5a361f037", null ],
    [ "fasp_amg_coarsening_rs", "coarsening__rs_8c.html#ac7c9fdc8a585185e9bf4d28ffba806f0", null ],
    [ "form_coarse_level", "coarsening__rs_8c.html#a86f563306d7789725fa0445b91be5179", null ],
    [ "form_coarse_level_ag", "coarsening__rs_8c.html#a4048b38dbcc9abc3b080e7e3ce8d7365", null ],
    [ "generate_S", "coarsening__rs_8c.html#a336d97c8fa7a4f1a596ae5f0294138f4", null ],
    [ "generate_S_rs", "coarsening__rs_8c.html#a13f77368fbe974b9414999d47e5fd26b", null ],
    [ "generate_S_rs_ag", "coarsening__rs_8c.html#a84935cb2f4237b3596e6405bf1c971cd", null ],
    [ "generate_sparsity_P", "coarsening__rs_8c.html#a4de486ec82a6c8a7a4eabca222704931", null ],
    [ "generate_sparsity_P_standard", "coarsening__rs_8c.html#a95710054b71cd572d1a837ab72cb85bf", null ],
    [ "remove_node", "coarsening__rs_8c.html#afa0f583f356c9090e8842ede065b262b", null ]
];