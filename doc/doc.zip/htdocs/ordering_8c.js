var ordering_8c =
[
    [ "fasp_aux_dQuickSort", "ordering_8c.html#aaf463fc61af8bb19262b862f3f6f4a38", null ],
    [ "fasp_aux_dQuickSortIndex", "ordering_8c.html#a9b86416aee75bae08b2b5de402356ac5", null ],
    [ "fasp_aux_iQuickSort", "ordering_8c.html#ab086dc830a83c1fa1cd5938801a9ef4e", null ],
    [ "fasp_aux_iQuickSortIndex", "ordering_8c.html#a4702dc827e3fd7b521ef285da64c06c3", null ],
    [ "fasp_aux_merge", "ordering_8c.html#a78a4d4fb679dbe6456391209d0e1553e", null ],
    [ "fasp_aux_msort", "ordering_8c.html#a86c8e1be37b2fba80320d770e6da8949", null ],
    [ "fasp_aux_unique", "ordering_8c.html#afbb22b17f0f8ec7e4eae9f0db9ec697a", null ],
    [ "fasp_BinarySearch", "ordering_8c.html#a70f70e1152b2674983135f82111c1958", null ],
    [ "fasp_dcsr_CMK_order", "ordering_8c.html#afe6c23ca92a2564891ae0839e8d43b61", null ],
    [ "fasp_dcsr_RCMK_order", "ordering_8c.html#a5f202274065c9b24f86539fad0c29053", null ]
];