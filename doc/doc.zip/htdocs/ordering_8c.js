var ordering_8c =
[
    [ "fasp_aux_dQuickSort", "ordering_8c.html#aaf463fc61af8bb19262b862f3f6f4a38", null ],
    [ "fasp_aux_dQuickSortIndex", "ordering_8c.html#a9b86416aee75bae08b2b5de402356ac5", null ],
    [ "fasp_aux_iQuickSort", "ordering_8c.html#ab086dc830a83c1fa1cd5938801a9ef4e", null ],
    [ "fasp_aux_iQuickSortIndex", "ordering_8c.html#a4702dc827e3fd7b521ef285da64c06c3", null ],
    [ "fasp_aux_merge", "ordering_8c.html#a78a4d4fb679dbe6456391209d0e1553e", null ],
    [ "fasp_aux_msort", "ordering_8c.html#a86c8e1be37b2fba80320d770e6da8949", null ],
    [ "fasp_aux_unique", "ordering_8c.html#a28aeaba69948224a16b458a477c57b7c", null ],
    [ "fasp_BinarySearch", "ordering_8c.html#a15ca189678504fa8b819edca8012cf77", null ]
];