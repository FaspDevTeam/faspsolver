var structprecond__diag__str =
[
    [ "diag", "structprecond__diag__str.html#aa2ab1984071b37d6300f7ddcc97c68de", null ],
    [ "nc", "structprecond__diag__str.html#a840f9c262c2132c2d9ce0c641101432f", null ]
];