var mg__util_8inl =
[
    [ "fasp_coarse_itsolver", "mg__util_8inl.html#a071bb4aa91148d6ee9431e2f8eff1477", null ],
    [ "fasp_dcsr_postsmoothing", "mg__util_8inl.html#a8f454edb5d5bd54d5b7640383b6b419c", null ],
    [ "fasp_dcsr_presmoothing", "mg__util_8inl.html#af5b18c815c8a4800095d68728827dcc6", null ]
];