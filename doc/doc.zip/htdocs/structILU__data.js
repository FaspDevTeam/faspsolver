var structILU__data =
[
    [ "A", "structILU__data.html#af9e6737b3e93ba85f7a406abe5d548de", null ],
    [ "col", "structILU__data.html#a35e7c2cd24fb4171cce3d78cd8bb3a23", null ],
    [ "ic", "structILU__data.html#aaf2a050f5529a5136300167401e051bc", null ],
    [ "icmap", "structILU__data.html#abd0ee25bc77a6530d1e38e03352529dd", null ],
    [ "ijlu", "structILU__data.html#a107bcaa8659bfc0f9cd64c8125d51867", null ],
    [ "ilevL", "structILU__data.html#af37cef34b25cc75a82c9eb8ab4e27cb8", null ],
    [ "ilevU", "structILU__data.html#afc741667fc2b54ea75dac2275497c51a", null ],
    [ "iperm", "structILU__data.html#ac5b44daf4b794bee687fdf74466d4bdb", null ],
    [ "jlevL", "structILU__data.html#acd858acf4a7631c30ee5dbee43cc7965", null ],
    [ "jlevU", "structILU__data.html#a3de146e6d2012f1ed1d93eeee6bfeddf", null ],
    [ "luval", "structILU__data.html#a23be394d0df4e880ef045c3c88217973", null ],
    [ "nb", "structILU__data.html#a71f3d0d1b9013165b0616c75e14ecb5d", null ],
    [ "ncolors", "structILU__data.html#a6722ff06a0e38db67d3bc54b0e2e8b4e", null ],
    [ "nlevL", "structILU__data.html#a8a92b2c8f67fdaab167dea87408ba3e0", null ],
    [ "nlevU", "structILU__data.html#a40447ee2ebf4b26e71eec686cffd06f6", null ],
    [ "nwork", "structILU__data.html#a56de6d1b71eeef2c0e89c8e4f10d0160", null ],
    [ "nzlu", "structILU__data.html#ac89b4073d58fed180d20a80623df49af", null ],
    [ "row", "structILU__data.html#a741a152c7b18c401af249dfb3a113c95", null ],
    [ "type", "structILU__data.html#a9a59b4d9fa62abe25a78cc38137ffd8e", null ],
    [ "uptr", "structILU__data.html#ae3b789ccc05c6c578f3c98de558c8fc5", null ],
    [ "work", "structILU__data.html#ade0e193fa0d5c88c37bd1f77f1148797", null ]
];