var blas__blc_8c =
[
    [ "fasp_blas_bdbsr_aAxpy", "blas__blc_8c.html#af535bd43d14629b9585caa5222a4a43e", null ],
    [ "fasp_blas_bdbsr_mxv", "blas__blc_8c.html#a87af2fba2a2f7314c7c6513f70942771", null ],
    [ "fasp_blas_dblc_aAxpy", "blas__blc_8c.html#ae6f6ecda804974a14bff2604725a4e83", null ],
    [ "fasp_blas_dblc_mxv", "blas__blc_8c.html#a3b98bea4c48166a695bfb1084795d287", null ]
];