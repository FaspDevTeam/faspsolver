var structdCSRmat =
[
    [ "col", "structdCSRmat.html#a35e7c2cd24fb4171cce3d78cd8bb3a23", null ],
    [ "IA", "structdCSRmat.html#a82a122cbfe1b4c4d010a147a0a72ebd1", null ],
    [ "JA", "structdCSRmat.html#ab39d8b2fa3fbf92c115fa73cb98bc7ce", null ],
    [ "nnz", "structdCSRmat.html#aa165c73f6701cd01aafc0868e6261dfe", null ],
    [ "row", "structdCSRmat.html#a741a152c7b18c401af249dfb3a113c95", null ],
    [ "val", "structdCSRmat.html#a6e543bb0c5acc1b10ba8e2a72eb92b52", null ]
];