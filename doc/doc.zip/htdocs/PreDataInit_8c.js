var PreDataInit_8c =
[
    [ "fasp_amg_data_bsr_create", "PreDataInit_8c.html#ac65fee742df3f05b202c282f0312da22", null ],
    [ "fasp_amg_data_bsr_free", "PreDataInit_8c.html#aea50a26f18ee25960d7c54ae076f0cdd", null ],
    [ "fasp_amg_data_create", "PreDataInit_8c.html#ab10ae5b0b47f43946dba4d039dc6e95d", null ],
    [ "fasp_amg_data_free", "PreDataInit_8c.html#ac902870ef1bb2a00d270e48f389d1992", null ],
    [ "fasp_ilu_data_create", "PreDataInit_8c.html#aa6cfba3bcda14a4b407c6d615cda038b", null ],
    [ "fasp_ilu_data_free", "PreDataInit_8c.html#ae3912d0c22b5ff78009cb746f41627b6", null ],
    [ "fasp_precond_data_init", "PreDataInit_8c.html#a00de578af3320eaf6cccefdff8018480", null ],
    [ "fasp_swz_data_free", "PreDataInit_8c.html#a4894130e6309fd0c98babdf6a0a58286", null ]
];