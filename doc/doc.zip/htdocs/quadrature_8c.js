var quadrature_8c =
[
    [ "fasp_gauss2d", "quadrature_8c.html#a5974227e7a9bd20335692a2fd1b35daa", null ],
    [ "fasp_quad2d", "quadrature_8c.html#aeb77f339bf5d8c23043d5085cce683a0", null ]
];