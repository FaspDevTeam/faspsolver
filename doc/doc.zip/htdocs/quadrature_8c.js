var quadrature_8c =
[
    [ "fasp_gauss2d", "quadrature_8c.html#aed9441eb02bfd842d72b312680dad560", null ],
    [ "fasp_quad2d", "quadrature_8c.html#ab30ac99319ef4c762e3d8012a344a4cb", null ]
];