var structgrid2d =
[
    [ "e", "structgrid2d.html#ad9e7980155d2e0120bff388aa85a2368", null ],
    [ "edges", "structgrid2d.html#a2f9b6c5c50894a96dcb406063f02986b", null ],
    [ "ediri", "structgrid2d.html#ad1e233111817db6d60a8efa547b40b5b", null ],
    [ "efather", "structgrid2d.html#a51c0d6122f0938e556c06fa654e7d3da", null ],
    [ "p", "structgrid2d.html#a2fdbdd0594f56a054e9ace9c140f94cd", null ],
    [ "pdiri", "structgrid2d.html#a1a4195f3b38e843f1825ce075588cf36", null ],
    [ "pfather", "structgrid2d.html#afa56d29460fa102ba7970e09bfc31a3a", null ],
    [ "s", "structgrid2d.html#a8279b80a452a022338f53b299cbee5e2", null ],
    [ "t", "structgrid2d.html#aa0e476c771c999a96003ecdf3da5286a", null ],
    [ "tfather", "structgrid2d.html#a7785c2c57ce2b2bd47e26568c38f3617", null ],
    [ "triangles", "structgrid2d.html#a3e3d0fff8b5ed5a478b138678662cf84", null ],
    [ "vertices", "structgrid2d.html#af4f9883eb2c15154302574c00a8fa343", null ]
];