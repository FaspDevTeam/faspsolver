var interpolation_8c =
[
    [ "fasp_amg_interp", "interpolation_8c.html#a71930a5b931c497e238e92dc88d449c6", null ],
    [ "fasp_amg_interp1", "interpolation_8c.html#a5f1f193262cc1b66607bfedbe4a19f80", null ],
    [ "fasp_amg_interp_trunc", "interpolation_8c.html#a8e8431c9d78b53a8e156a57c0520914e", null ]
];