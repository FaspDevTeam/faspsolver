var interpolation_8c =
[
    [ "fasp_amg_interp", "interpolation_8c.html#add8e3fbc139ddea5a808a7bc963c9531", null ],
    [ "fasp_amg_interp1", "interpolation_8c.html#a2110c163f16da3628fafd7ca52672e0f", null ],
    [ "fasp_BinarySearch", "interpolation_8c.html#a15ca189678504fa8b819edca8012cf77", null ]
];