var forts__ns_8h =
[
    [ "bbgs2ns_", "forts__ns_8h.html#a3074761b11f23f3ab3dcbc40701bdf60", null ],
    [ "chsize_", "forts__ns_8h.html#aa5ff05b195b02b488bf9d6c5c90e268d", null ],
    [ "cut0_", "forts__ns_8h.html#a686912461e8f735a77e07881a8c131f9", null ],
    [ "dfs_", "forts__ns_8h.html#ac84bd49452c64a24f84d593a5f107bca", null ],
    [ "dolu_", "forts__ns_8h.html#a1376531ce240cdd2097674ff43578990", null ],
    [ "doluns_", "forts__ns_8h.html#a41b9f6f217204d352e05185c1bc1a9e4", null ],
    [ "fbgs2ns_", "forts__ns_8h.html#ac4eb301526128b00fab62d98d91ac9a7", null ],
    [ "icopyv_", "forts__ns_8h.html#a102b83dbecfc53ab893c6b5e7306a152", null ],
    [ "ijacrs_", "forts__ns_8h.html#aa59ab4ac31c42a64c1adab68dc5d7cf1", null ],
    [ "levels_", "forts__ns_8h.html#a2648c5e5ac8d7a84ce6a98a4ea710794", null ],
    [ "mxfrm2_", "forts__ns_8h.html#ad7bf383abf3b9ad976a45ec80d19b2c1", null ],
    [ "perback_", "forts__ns_8h.html#a6a800f22dadc362ac50f49bc12d4845f", null ],
    [ "perm0_", "forts__ns_8h.html#a299111998702d1ba61cf5900d5311e2b", null ],
    [ "permat_", "forts__ns_8h.html#a9eee0093ec79cde8ae2b8287e51adeec", null ],
    [ "pervec_", "forts__ns_8h.html#afb2264f7000e5eae4f5e94b3cc8e4349", null ],
    [ "shift_", "forts__ns_8h.html#a159282e19f9831e6743a057bd2f3b6c5", null ],
    [ "sky2ns_", "forts__ns_8h.html#afc1a61338af80685db66d4e006002678", null ],
    [ "sluns_", "forts__ns_8h.html#a406479d396b8e9bd0a2d2f087d5d2f11", null ],
    [ "slvlu_", "forts__ns_8h.html#a4777bce967e126a51d3383284a73e93a", null ],
    [ "sympat_", "forts__ns_8h.html#aa29dfecf3c2c4e2e6478d388e4e004dd", null ]
];