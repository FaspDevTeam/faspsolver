var gmg__poisson_8c =
[
    [ "fasp_poisson_fgmg_1D", "gmg__poisson_8c.html#a16c81b531c6936cc7763ab0bc47a1b9a", null ],
    [ "fasp_poisson_fgmg_2D", "gmg__poisson_8c.html#a16932d1660a8a52e20050074082006b8", null ],
    [ "fasp_poisson_fgmg_3D", "gmg__poisson_8c.html#a4fd4f3e6533fbd41e08ba2a6a7fcc752", null ],
    [ "fasp_poisson_gmg_1D", "gmg__poisson_8c.html#a2a958a2a10c6b44401f0eefca2388cb5", null ],
    [ "fasp_poisson_gmg_2D", "gmg__poisson_8c.html#a24543d9019d39e5deb3c9d41916a8e87", null ],
    [ "fasp_poisson_gmg_3D", "gmg__poisson_8c.html#a2c057e3bc355220fd9db5e41b4419028", null ],
    [ "fasp_poisson_pcg_gmg_1D", "gmg__poisson_8c.html#a3fb7ee671bfd47f396d91b2405c475de", null ],
    [ "fasp_poisson_pcg_gmg_2D", "gmg__poisson_8c.html#ae8450b9bfed6052444ec277d4c67c0e6", null ],
    [ "fasp_poisson_pcg_gmg_3D", "gmg__poisson_8c.html#afb9bd0c0b10c6af767ba731518425cdc", null ]
];