var gmg__poisson_8c =
[
    [ "fasp_poisson_fgmg_1D", "gmg__poisson_8c.html#a7f5aec5d1d80d704b9f71103bc01300e", null ],
    [ "fasp_poisson_fgmg_2D", "gmg__poisson_8c.html#a4d3a8c7f2d10ee9829bb118f8dce7eb4", null ],
    [ "fasp_poisson_fgmg_3D", "gmg__poisson_8c.html#a3ae3f16bb191940cfaeb06215377bc3c", null ],
    [ "fasp_poisson_gmg_1D", "gmg__poisson_8c.html#ad3c4c21b8355fb0e65f82272067388c8", null ],
    [ "fasp_poisson_gmg_2D", "gmg__poisson_8c.html#a638cc4f3235530d1b6a0373318629ca9", null ],
    [ "fasp_poisson_gmg_3D", "gmg__poisson_8c.html#a98dd346817fb032d1b16f4c7ccb8a12b", null ],
    [ "fasp_poisson_pcg_gmg_1D", "gmg__poisson_8c.html#af78dce92f7b268e85c5447b687a780d6", null ],
    [ "fasp_poisson_pcg_gmg_2D", "gmg__poisson_8c.html#aaa7f3940bf12a5e4378b260fa1a0ae86", null ],
    [ "fasp_poisson_pcg_gmg_3D", "gmg__poisson_8c.html#a9e1d36276cf25318fd38d6663eef399f", null ]
];