var gmg__poisson_8c =
[
    [ "fasp_poisson_fgmg_1D", "gmg__poisson_8c.html#a16c81b531c6936cc7763ab0bc47a1b9a", null ],
    [ "fasp_poisson_fgmg_2D", "gmg__poisson_8c.html#a16932d1660a8a52e20050074082006b8", null ],
    [ "fasp_poisson_fgmg_3D", "gmg__poisson_8c.html#a4fd4f3e6533fbd41e08ba2a6a7fcc752", null ],
    [ "fasp_poisson_gmg_1D", "gmg__poisson_8c.html#aaf9c7b36499ba81feb244839ec2b7650", null ],
    [ "fasp_poisson_gmg_2D", "gmg__poisson_8c.html#a6ba0ababb77dfb8ee0c436f982df596f", null ],
    [ "fasp_poisson_gmg_3D", "gmg__poisson_8c.html#a2ba5bb1cd1d7499d7e4d58eb42b89317", null ],
    [ "fasp_poisson_pcg_gmg_1D", "gmg__poisson_8c.html#a3fb7ee671bfd47f396d91b2405c475de", null ],
    [ "fasp_poisson_pcg_gmg_2D", "gmg__poisson_8c.html#ae8450b9bfed6052444ec277d4c67c0e6", null ],
    [ "fasp_poisson_pcg_gmg_3D", "gmg__poisson_8c.html#afb9bd0c0b10c6af767ba731518425cdc", null ]
];