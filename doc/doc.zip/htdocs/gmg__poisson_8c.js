var gmg__poisson_8c =
[
    [ "fasp_poisson_fgmg_1D", "gmg__poisson_8c.html#a8a0352355527e1cc7e5d5d3769ba24e0", null ],
    [ "fasp_poisson_fgmg_2D", "gmg__poisson_8c.html#a7b0b3c3dd06c1e9db99fd3412a9e6dc0", null ],
    [ "fasp_poisson_fgmg_3D", "gmg__poisson_8c.html#a139490365e3ad56a0075b4495ca7b54c", null ],
    [ "fasp_poisson_gmg_1D", "gmg__poisson_8c.html#a2a958a2a10c6b44401f0eefca2388cb5", null ],
    [ "fasp_poisson_gmg_2D", "gmg__poisson_8c.html#a24543d9019d39e5deb3c9d41916a8e87", null ],
    [ "fasp_poisson_gmg_3D", "gmg__poisson_8c.html#a2c057e3bc355220fd9db5e41b4419028", null ],
    [ "fasp_poisson_pcg_gmg_1D", "gmg__poisson_8c.html#a4c7a63d2eac71928a7f14c0b6ad3c83e", null ],
    [ "fasp_poisson_pcg_gmg_2D", "gmg__poisson_8c.html#aa0703c44dae246024e8cc7b7e58528fc", null ],
    [ "fasp_poisson_pcg_gmg_3D", "gmg__poisson_8c.html#a212de8b0e2d365ff9be5dcb5b78c52c9", null ]
];