var gmg__poisson_8c =
[
    [ "fasp_poisson_fgmg_1D", "gmg__poisson_8c.html#aed0191ab01cf1397414f4a0130030064", null ],
    [ "fasp_poisson_fgmg_2D", "gmg__poisson_8c.html#a0c67a123005325204c0ab2913c0724e6", null ],
    [ "fasp_poisson_fgmg_3D", "gmg__poisson_8c.html#a15a09b4b3e20b950498a7bb885804cf1", null ],
    [ "fasp_poisson_gmg_1D", "gmg__poisson_8c.html#aa83206b0ecac393b4f6bebeb2afe2343", null ],
    [ "fasp_poisson_gmg_2D", "gmg__poisson_8c.html#af7403bf36e337815e364ddb3caf77463", null ],
    [ "fasp_poisson_gmg_3D", "gmg__poisson_8c.html#a564b389a67bc49991d4487ecb9b9d432", null ],
    [ "fasp_poisson_pcg_gmg_1D", "gmg__poisson_8c.html#af7d5a7ddbb7bcb1a1dcbde8ac88a813b", null ],
    [ "fasp_poisson_pcg_gmg_2D", "gmg__poisson_8c.html#af2f63e7c61106d09dd205031f87c2d25", null ],
    [ "fasp_poisson_pcg_gmg_3D", "gmg__poisson_8c.html#a970a2a841b4b5944e5579a09174d2b8d", null ]
];