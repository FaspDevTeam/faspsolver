var searchData=
[
  ['b',['b',['../structAMG__data.html#a921cb3b9308d321aa1956ca99e2c6a6a',1,'AMG_data::b()'],['../structAMG__data__bsr.html#a921cb3b9308d321aa1956ca99e2c6a6a',1,'AMG_data_bsr::b()']]],
  ['bcol',['bcol',['../structblock__dCSRmat.html#aa72f0e4b562f9818797596099fb8ac41',1,'block_dCSRmat::bcol()'],['../structblock__iCSRmat.html#aa72f0e4b562f9818797596099fb8ac41',1,'block_iCSRmat::bcol()']]],
  ['bigreal',['BIGREAL',['../fasp_8h.html#a9457fe109bc3300d1b5b969c1bb30136',1,'fasp.h']]],
  ['blas_5farray_2ec',['blas_array.c',['../blas__array_8c.html',1,'']]],
  ['blas_5fbcsr_2ec',['blas_bcsr.c',['../blas__bcsr_8c.html',1,'']]],
  ['blas_5fbsr_2ec',['blas_bsr.c',['../blas__bsr_8c.html',1,'']]],
  ['blas_5fcsr_2ec',['blas_csr.c',['../blas__csr_8c.html',1,'']]],
  ['blas_5fcsrl_2ec',['blas_csrl.c',['../blas__csrl_8c.html',1,'']]],
  ['blas_5fsmat_2ec',['blas_smat.c',['../blas__smat_8c.html',1,'']]],
  ['blas_5fstr_2ec',['blas_str.c',['../blas__str_8c.html',1,'']]],
  ['blas_5fvec_2ec',['blas_vec.c',['../blas__vec_8c.html',1,'']]],
  ['block_5fbsr',['block_BSR',['../structblock__BSR.html',1,'block_BSR'],['../fasp__block_8h.html#a84755e45fefdd4e0b01f1bc3c1539e45',1,'block_BSR():&#160;fasp_block.h']]],
  ['block_5fdcsrmat',['block_dCSRmat',['../structblock__dCSRmat.html',1,'block_dCSRmat'],['../fasp__block_8h.html#a385861710addc9588d806060bda8e566',1,'block_dCSRmat():&#160;fasp_block.h']]],
  ['block_5fdvector',['block_dvector',['../structblock__dvector.html',1,'block_dvector'],['../fasp__block_8h.html#adddfc2e04d46b626669d27f34b9ef032',1,'block_dvector():&#160;fasp_block.h']]],
  ['block_5ficsrmat',['block_iCSRmat',['../structblock__iCSRmat.html',1,'block_iCSRmat'],['../fasp__block_8h.html#a431e53d1892f0ea1ca96f669944be454',1,'block_iCSRmat():&#160;fasp_block.h']]],
  ['block_5fivector',['block_ivector',['../structblock__ivector.html',1,'block_ivector'],['../fasp__block_8h.html#ae0755b0aff70990c951030297946ee4a',1,'block_ivector():&#160;fasp_block.h']]],
  ['block_5freservoir',['block_Reservoir',['../structblock__Reservoir.html',1,'block_Reservoir'],['../fasp__block_8h.html#aacef4ade58c89c2972c322c4d463a429',1,'block_Reservoir():&#160;fasp_block.h']]],
  ['blocks',['blocks',['../structblock__dCSRmat.html#a7327f8619a03f7573ce011259cf8ff12',1,'block_dCSRmat::blocks()'],['../structblock__iCSRmat.html#a8cea7044158e2bbc32709339144ab0cf',1,'block_iCSRmat::blocks()'],['../structblock__dvector.html#a5c2696b5f63cbf8b3b88d90cf5f6e242',1,'block_dvector::blocks()'],['../structblock__ivector.html#ab53c571e03eaa11827a457509fff582b',1,'block_ivector::blocks()']]],
  ['brow',['brow',['../structblock__dCSRmat.html#a0c327386c4e9c982b15bcc8726a16dd6',1,'block_dCSRmat::brow()'],['../structblock__iCSRmat.html#a0c327386c4e9c982b15bcc8726a16dd6',1,'block_iCSRmat::brow()'],['../structblock__dvector.html#a0c327386c4e9c982b15bcc8726a16dd6',1,'block_dvector::brow()'],['../structblock__ivector.html#a0c327386c4e9c982b15bcc8726a16dd6',1,'block_ivector::brow()']]],
  ['building_20and_20installation',['Building and Installation',['../build.html',1,'']]]
];
