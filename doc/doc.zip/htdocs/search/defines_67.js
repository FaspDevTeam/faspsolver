var searchData=
[
  ['ge',['GE',['../fasp_8h.html#a2c6429d4fb4427b81f818926c5a02394',1,'fasp.h']]],
  ['gt',['GT',['../fasp_8h.html#ad70f566908afbab695da92d22f53953b',1,'fasp.h']]]
];
