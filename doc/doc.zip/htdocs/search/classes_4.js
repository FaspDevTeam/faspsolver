var searchData=
[
  ['iblcmat',['iBLCmat',['../structiBLCmat.html',1,'']]],
  ['icoomat',['iCOOmat',['../structiCOOmat.html',1,'']]],
  ['icsrmat',['iCSRmat',['../structiCSRmat.html',1,'']]],
  ['idenmat',['idenmat',['../structidenmat.html',1,'']]],
  ['ilu_5fdata',['ILU_data',['../structILU__data.html',1,'']]],
  ['ilu_5fparam',['ILU_param',['../structILU__param.html',1,'']]],
  ['input_5fparam',['input_param',['../structinput__param.html',1,'']]],
  ['itsolver_5fparam',['itsolver_param',['../structitsolver__param.html',1,'']]],
  ['ivector',['ivector',['../structivector.html',1,'']]]
];
