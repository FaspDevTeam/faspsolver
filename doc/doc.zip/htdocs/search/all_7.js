var searchData=
[
  ['g0pt',['G0PT',['../fasp__const_8h.html#af6a025855d8e327727eb4d71cce904ce',1,'fasp_const.h']]],
  ['ge',['GE',['../fasp_8h.html#a2c6429d4fb4427b81f818926c5a02394',1,'fasp.h']]],
  ['givens_2ec',['givens.c',['../givens_8c.html',1,'']]],
  ['gmg_5fpoisson_2ec',['gmg_poisson.c',['../gmg__poisson_8c.html',1,'']]],
  ['gmg_5futil_2einl',['gmg_util.inl',['../gmg__util_8inl.html',1,'']]],
  ['graphics_2ec',['graphics.c',['../graphics_8c.html',1,'']]],
  ['grid2d',['grid2d',['../structgrid2d.html',1,'grid2d'],['../fasp_8h.html#a79023b84c5ab274995e47b8edd7d33d4',1,'grid2d():&#160;fasp.h']]],
  ['gt',['GT',['../fasp_8h.html#ad70f566908afbab695da92d22f53953b',1,'fasp.h']]]
];
