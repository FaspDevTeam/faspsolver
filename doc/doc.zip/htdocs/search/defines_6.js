var searchData=
[
  ['false',['FALSE',['../fasp__const_8h.html#aa93f0eb578d23995850d61f7d61c55c1',1,'fasp_const.h']]],
  ['fasp_5fsuccess',['FASP_SUCCESS',['../fasp__const_8h.html#a2fab34f5c05d4417f7514b551503ab6b',1,'fasp_const.h']]],
  ['fasp_5fversion',['FASP_VERSION',['../fasp_8h.html#a8328d92e9bc0ee72f08a3c9296c325bb',1,'fasp.h']]],
  ['fgpt',['FGPT',['../fasp__const_8h.html#a3d4e87644819e2789248e1d408793efb',1,'fasp_const.h']]],
  ['fpfirst',['FPFIRST',['../fasp__const_8h.html#a1272ba060bccad2e16cdbdd082faefa8',1,'fasp_const.h']]]
];
