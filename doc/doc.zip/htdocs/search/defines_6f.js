var searchData=
[
  ['off',['OFF',['../messages_8h.html#a29e413f6725b2ba32d165ffaa35b01e5',1,'messages.h']]],
  ['on',['ON',['../messages_8h.html#ad76d1750a6cdeebd506bfcd6752554d2',1,'messages.h']]],
  ['openmp_5fholds',['OPENMP_HOLDS',['../fasp_8h.html#a9e666c6cae3542e89bf5d8467ff10bdb',1,'fasp.h']]]
];
