var searchData=
[
  ['main',['main',['../poisson-amg_8c.html#ac0f2228420376f4db7e1274f2b41667c',1,'poisson-amg.c']]],
  ['mesh_5faux_5fbuild',['mesh_aux_build',['../mesh_8c.html#aa2b6fad96f8e15389da3570938ebe324',1,'mesh.c']]],
  ['mesh_5faux_5ffree',['mesh_aux_free',['../mesh_8c.html#af1a3e8169c2b0954b8bd8c75e98b4d26',1,'mesh.c']]],
  ['mesh_5faux_5finit',['mesh_aux_init',['../mesh_8c.html#adf575c6cad7adb0c0c3fbac06b8cec99',1,'mesh.c']]],
  ['mesh_5faux_5finit_5fpro',['mesh_aux_init_pro',['../mesh_8c.html#a90ee7e544f5a5c82e429d7f62673dfc5',1,'mesh.c']]],
  ['mesh_5faux_5fwrite',['mesh_aux_write',['../mesh_8c.html#ab1c25eef60793f20cb70be72d52ef5b3',1,'mesh.c']]],
  ['mesh_5faux_5fwrite_5fpro',['mesh_aux_write_pro',['../mesh_8c.html#a01b0bdb264e3f970a595aac6a9a2c507',1,'mesh.c']]],
  ['mesh_5ffree',['mesh_free',['../mesh_8c.html#a4dbb6ac6ad83837ed75e916dd5bf9a06',1,'mesh.c']]],
  ['mesh_5finit',['mesh_init',['../mesh_8c.html#a2608e571ec4af24df40e0dc1ed744340',1,'mesh.c']]],
  ['mesh_5finit_5fpro',['mesh_init_pro',['../mesh_8c.html#a99722d3680d20abe7849d3280cc3dc6f',1,'mesh.c']]],
  ['mesh_5frefine',['mesh_refine',['../mesh_8c.html#a9f3c9563e0ff5d7137fbe561760cade8',1,'mesh.c']]],
  ['mesh_5fwrite',['mesh_write',['../mesh_8c.html#ae4586bae1b5e25edce70a76083921ff0',1,'mesh.c']]],
  ['mesh_5fwrite_5fpro',['mesh_write_pro',['../mesh_8c.html#afafc56de5f9bf9203fa70182fba7d63d',1,'mesh.c']]]
];
