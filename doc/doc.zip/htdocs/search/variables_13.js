var searchData=
[
  ['w',['w',['../structAMG__data.html#afac201e84bf6f4b14287c1463d10e688',1,'AMG_data::w()'],['../structprecond__data.html#a65a6c7b16e05fbe6ce87e7864ef4b134',1,'precond_data::w()'],['../structprecond__data__str.html#a65a6c7b16e05fbe6ce87e7864ef4b134',1,'precond_data_str::w()'],['../structAMG__data__bsr.html#afac201e84bf6f4b14287c1463d10e688',1,'AMG_data_bsr::w()'],['../structprecond__data__bsr.html#a65a6c7b16e05fbe6ce87e7864ef4b134',1,'precond_data_bsr::w()'],['../structprecond__data__sweeping.html#a65a6c7b16e05fbe6ce87e7864ef4b134',1,'precond_data_sweeping::w()']]],
  ['weight',['weight',['../structAMG__data.html#afe09a839daf27120458f54f413ba34fc',1,'AMG_data']]],
  ['work',['work',['../structILU__data.html#ade0e193fa0d5c88c37bd1f77f1148797',1,'ILU_data']]],
  ['workdir',['workdir',['../structinput__param.html#a354cb994af40a006776e0769ef9914c4',1,'input_param']]]
];
