var searchData=
[
  ['remove_5fnode',['remove_node',['../coarsening__rs_8c.html#afa0f583f356c9090e8842ede065b262b',1,'coarsening_rs.c']]],
  ['rr',['Rr',['../smoother__poly_8c.html#a23117bc3cd8e5173fcac20656b5fa51b',1,'smoother_poly.c']]]
];
