var searchData=
[
  ['remove_5fnode',['remove_node',['../coarsening__rs_8c.html#afa0f583f356c9090e8842ede065b262b',1,'coarsening_rs.c']]]
];
