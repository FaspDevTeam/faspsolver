var searchData=
[
  ['real',['REAL',['../fasp_8h.html#a4b654506f18b8bfd61ad2a29a7e38c25',1,'fasp.h']]],
  ['rs_5fc1',['RS_C1',['../fasp_8h.html#ae9cf94d2098b4b6b4f41ee68de767922',1,'fasp.h']]],
  ['run_5ffail',['RUN_FAIL',['../messages_8h.html#a5b20d50cafe86070426e0d0c1691f08d',1,'messages.h']]]
];
