var searchData=
[
  ['mask',['mask',['../structSWZ__data.html#a06ef238edd833cd958011d0bd71c7817',1,'SWZ_data']]],
  ['max_5faggregation',['max_aggregation',['../structAMG__param.html#ad3834447364686e0c4f1c773d9921e56',1,'AMG_param']]],
  ['max_5flevels',['max_levels',['../structAMG__param.html#ac7f8740ade9a83cb649a880d329cbcf8',1,'AMG_param::max_levels()'],['../structAMG__data.html#ac7f8740ade9a83cb649a880d329cbcf8',1,'AMG_data::max_levels()'],['../structprecond__data.html#ac7f8740ade9a83cb649a880d329cbcf8',1,'precond_data::max_levels()'],['../structprecond__data__str.html#ac7f8740ade9a83cb649a880d329cbcf8',1,'precond_data_str::max_levels()'],['../structAMG__data__bsr.html#abc4dc717b5bb7b0927554073c84ee0e9',1,'AMG_data_bsr::max_levels()'],['../structprecond__data__bsr.html#abc4dc717b5bb7b0927554073c84ee0e9',1,'precond_data_bsr::max_levels()']]],
  ['max_5frow_5fsum',['max_row_sum',['../structAMG__param.html#aec0841262dd2d0c99a18a39e576fc479',1,'AMG_param']]],
  ['maxa',['maxa',['../structSWZ__data.html#aeaff9bb8aef2889ae3d5768ca37f5106',1,'SWZ_data']]],
  ['maxbs',['maxbs',['../structSWZ__data.html#a1b5dd0b135eb48391796ca1d0a150c5e',1,'SWZ_data']]],
  ['maxit',['maxit',['../structITS__param.html#af611c2bf78bd31105bcc3e241b12e549',1,'ITS_param::maxit()'],['../structAMG__param.html#af611c2bf78bd31105bcc3e241b12e549',1,'AMG_param::maxit()'],['../structprecond__data.html#af611c2bf78bd31105bcc3e241b12e549',1,'precond_data::maxit()'],['../structprecond__data__str.html#af611c2bf78bd31105bcc3e241b12e549',1,'precond_data_str::maxit()'],['../structprecond__data__bsr.html#af611c2bf78bd31105bcc3e241b12e549',1,'precond_data_bsr::maxit()']]],
  ['memt',['memt',['../structSWZ__data.html#a050caadcd37ff4b65062a38c0ad13f08',1,'SWZ_data']]],
  ['mgl',['mgl',['../structprecond__block__data.html#a86e6851254ff0a1314cbe05be78e7abf',1,'precond_block_data']]],
  ['mgl_5fdata',['mgl_data',['../structprecond__data.html#a43974340a16a9abd3dd5828c334fa43c',1,'precond_data::mgl_data()'],['../structprecond__data__str.html#a43974340a16a9abd3dd5828c334fa43c',1,'precond_data_str::mgl_data()'],['../structprecond__data__bsr.html#abb2227338d3434410a7bb3e5e5d23602',1,'precond_data_bsr::mgl_data()']]],
  ['million',['Million',['../AuxMemory_8c.html#a0c885651acd7763a76a1ebbefd9c4a50',1,'AuxMemory.c']]],
  ['mumps',['mumps',['../structSWZ__data.html#aaf667526ec4a4a01cd527fffad2e67b3',1,'SWZ_data::mumps()'],['../structAMG__data.html#a768df12bab35f908514f8e37ee02d8cf',1,'AMG_data::mumps()'],['../structAMG__data__bsr.html#a768df12bab35f908514f8e37ee02d8cf',1,'AMG_data_bsr::mumps()']]]
];
