var searchData=
[
  ['dcsrmat2samginput',['dCSRmat2SAMGInput',['../interface__samg_8c.html#a66c3150eebb37e2c6564f43d3860ee0b',1,'interface_samg.c']]],
  ['dcsrmat_5fdivision_5fgroups',['dCSRmat_Division_Groups',['../amg__setup__rs_8c.html#a430d1f7627e331183569de52c52cff32',1,'amg_setup_rs.c']]],
  ['dvector2samginput',['dvector2SAMGInput',['../interface__samg_8c.html#a2bbc014a531ed669e3cec20188538a4a',1,'interface_samg.c']]]
];
