var searchData=
[
  ['dcsrmat2samginput',['dCSRmat2SAMGInput',['../interface__samg_8c.html#a66c3150eebb37e2c6564f43d3860ee0b',1,'interface_samg.c']]],
  ['dvector2samginput',['dvector2SAMGInput',['../interface__samg_8c.html#a2bbc014a531ed669e3cec20188538a4a',1,'interface_samg.c']]]
];
