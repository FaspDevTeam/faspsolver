var searchData=
[
  ['dcsr_5foutput',['dcsr_output',['../assemble_8c.html#aed29365c3706745797ac0b00db586c89',1,'assemble.c']]],
  ['dden_5foutput',['dden_output',['../assemble_8c.html#ae2aa4b7b958d9cadc1734eb32877c666',1,'assemble.c']]],
  ['diaginv',['Diaginv',['../smoother__poly_8c.html#aa0f4b37cabe6e8bec6bc82d98eafbc4a',1,'smoother_poly.c']]],
  ['diagx',['Diagx',['../smoother__poly_8c.html#a5eec60e4da01ed046442749cf8ff5a3d',1,'smoother_poly.c']]],
  ['dinvanorminf',['DinvAnorminf',['../smoother__poly_8c.html#a8fb4a2313b68e91706d013d88eb6f6fc',1,'smoother_poly.c']]],
  ['dispose_5fnode',['dispose_node',['../coarsening__rs_8c.html#ac5bafe3c53d0002830e7f6ed86ffa49e',1,'coarsening_rs.c']]],
  ['dswapping',['dSwapping',['../ordering_8c.html#afca6748aea4d52e7527fb6dd225cd99b',1,'ordering.c']]],
  ['dvec_5foutput',['dvec_output',['../assemble_8c.html#a919c24043f5f6401487c979e386f6805',1,'assemble.c']]]
];
