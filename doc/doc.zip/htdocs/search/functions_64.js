var searchData=
[
  ['dcsrmat2samginput',['dCSRmat2SAMGInput',['../interface__samg_8c.html#aa5b8bc5d87cae1eebed6828d53e8ccc0',1,'interface_samg.c']]],
  ['dcsrmat_5fdivision_5fgroups',['dCSRmat_Division_Groups',['../amg__setup__rs_8c.html#aa72a274a0ec58728ac31df9e465e71b1',1,'amg_setup_rs.c']]],
  ['dvector2samginput',['dvector2SAMGInput',['../interface__samg_8c.html#a2bbc014a531ed669e3cec20188538a4a',1,'interface_samg.c']]]
];
