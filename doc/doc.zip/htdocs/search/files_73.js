var searchData=
[
  ['schwarz_2ef',['schwarz.f',['../schwarz_8f.html',1,'']]],
  ['schwarz_5fsetup_2ec',['schwarz_setup.c',['../schwarz__setup_8c.html',1,'']]],
  ['smat_2ec',['smat.c',['../smat_8c.html',1,'']]],
  ['smoother_5fbsr_2ec',['smoother_bsr.c',['../smoother__bsr_8c.html',1,'']]],
  ['smoother_5fcr_2ec',['smoother_cr.c',['../smoother__cr_8c.html',1,'']]],
  ['smoother_5fcsr_2ec',['smoother_csr.c',['../smoother__csr_8c.html',1,'']]],
  ['smoother_5fpoly_2ec',['smoother_poly.c',['../smoother__poly_8c.html',1,'']]],
  ['smoother_5fstr_2ec',['smoother_str.c',['../smoother__str_8c.html',1,'']]],
  ['sparse_5fblock_2ec',['sparse_block.c',['../sparse__block_8c.html',1,'']]],
  ['sparse_5fbsr_2ec',['sparse_bsr.c',['../sparse__bsr_8c.html',1,'']]],
  ['sparse_5fcoo_2ec',['sparse_coo.c',['../sparse__coo_8c.html',1,'']]],
  ['sparse_5fcsr_2ec',['sparse_csr.c',['../sparse__csr_8c.html',1,'']]],
  ['sparse_5fcsrl_2ec',['sparse_csrl.c',['../sparse__csrl_8c.html',1,'']]],
  ['sparse_5fstr_2ec',['sparse_str.c',['../sparse__str_8c.html',1,'']]],
  ['sparse_5futil_2ec',['sparse_util.c',['../sparse__util_8c.html',1,'']]]
];
