var searchData=
[
  ['quadrature_2ec',['quadrature.c',['../quadrature_8c.html',1,'']]]
];
