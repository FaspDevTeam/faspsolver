var searchData=
[
  ['endian_5fconvert_5fint',['endian_convert_int',['../AuxConvert_8c.html#aa4af8461d5005ce36155b5f51fa58544',1,'AuxConvert.c']]],
  ['endian_5fconvert_5freal',['endian_convert_real',['../AuxConvert_8c.html#a7d54e77fcea737747361e4bba5bce3a7',1,'AuxConvert.c']]]
];
