var searchData=
[
  ['_5f_5ffasp_5fheader_5f_5f',['__FASP_HEADER__',['../fasp_8h.html#ac03f4b0d4a2b6dfd9e4195cd20554c4b',1,'fasp.h']]],
  ['_5f_5ffaspblock_5fheader_5f_5f',['__FASPBLOCK_HEADER__',['../fasp__block_8h.html#aee9c3718795a97070ae2cf90bab99870',1,'fasp_block.h']]]
];
