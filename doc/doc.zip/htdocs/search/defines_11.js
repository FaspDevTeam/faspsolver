var searchData=
[
  ['ua_5famg',['UA_AMG',['../fasp__const_8h.html#afd263e443292d581ba90928f142d709a',1,'fasp_const.h']]],
  ['unpt',['UNPT',['../fasp__const_8h.html#a74ea58908bcd4062248c5829f56761c0',1,'fasp_const.h']]],
  ['userdefined',['USERDEFINED',['../fasp__const_8h.html#aba2be20c77089257ed00d4081a809097',1,'fasp_const.h']]],
  ['uspair',['USPAIR',['../fasp__const_8h.html#a624ca53868c4852734c525bc0050b9a5',1,'fasp_const.h']]]
];
