var searchData=
[
  ['link',['Link',['../structLink.html',1,'']]],
  ['linked_5flist',['linked_list',['../structlinked__list.html',1,'']]]
];
