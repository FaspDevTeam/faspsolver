var searchData=
[
  ['b',['b',['../structAMG__data.html#a921cb3b9308d321aa1956ca99e2c6a6a',1,'AMG_data::b()'],['../structAMG__data__bsr.html#a921cb3b9308d321aa1956ca99e2c6a6a',1,'AMG_data_bsr::b()']]],
  ['bcol',['bcol',['../structdBLCmat.html#aa72f0e4b562f9818797596099fb8ac41',1,'dBLCmat::bcol()'],['../structiBLCmat.html#aa72f0e4b562f9818797596099fb8ac41',1,'iBLCmat::bcol()']]],
  ['blk_5fdata',['blk_data',['../structSWZ__data.html#a8bc0efce260b46b9f84c35fdad174191',1,'SWZ_data']]],
  ['blk_5fsolver',['blk_solver',['../structSWZ__data.html#aa8bc9d8e9c8d69d74282a5b3054c90ea',1,'SWZ_data']]],
  ['blocks',['blocks',['../structdBLCmat.html#a7327f8619a03f7573ce011259cf8ff12',1,'dBLCmat::blocks()'],['../structiBLCmat.html#a8cea7044158e2bbc32709339144ab0cf',1,'iBLCmat::blocks()'],['../structblock__dvector.html#a5c2696b5f63cbf8b3b88d90cf5f6e242',1,'block_dvector::blocks()'],['../structblock__ivector.html#ab53c571e03eaa11827a457509fff582b',1,'block_ivector::blocks()']]],
  ['brow',['brow',['../structdBLCmat.html#a0c327386c4e9c982b15bcc8726a16dd6',1,'dBLCmat::brow()'],['../structiBLCmat.html#a0c327386c4e9c982b15bcc8726a16dd6',1,'iBLCmat::brow()'],['../structblock__dvector.html#a0c327386c4e9c982b15bcc8726a16dd6',1,'block_dvector::brow()'],['../structblock__ivector.html#a0c327386c4e9c982b15bcc8726a16dd6',1,'block_ivector::brow()']]]
];
