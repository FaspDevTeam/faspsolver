var searchData=
[
  ['real',['REAL',['../fasp_8h.html#a4b654506f18b8bfd61ad2a29a7e38c25',1,'fasp.h']]],
  ['run_5ffail',['RUN_FAIL',['../messages_8h.html#a5b20d50cafe86070426e0d0c1691f08d',1,'messages.h']]]
];
