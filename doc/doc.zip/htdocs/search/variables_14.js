var searchData=
[
  ['x',['x',['../structAMG__data.html#abc14393d10a69508c5f56f85abd6670c',1,'AMG_data::x()'],['../structAMG__data__bsr.html#abc14393d10a69508c5f56f85abd6670c',1,'AMG_data_bsr::x()']]],
  ['xloc1',['xloc1',['../structSWZ__data.html#a6774a4ebc40deaf07352694a56300dca',1,'SWZ_data']]]
];
