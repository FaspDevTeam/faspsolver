var searchData=
[
  ['offdiag',['offdiag',['../structdSTRmat.html#ad9769afd89d479d98bb9843d08c7f0d9',1,'dSTRmat']]],
  ['offsets',['offsets',['../structdSTRmat.html#a18c718e8123868e8178fcc7ec9265f26',1,'dSTRmat']]],
  ['order',['order',['../structprecond__data__str.html#a7a633bb60cf95b0a793221432750c07a',1,'precond_data_str::order()'],['../structprecond__block__reservoir__data.html#a7a633bb60cf95b0a793221432750c07a',1,'precond_block_reservoir_data::order()'],['../structprecond__FASP__blkoil__data.html#a7a633bb60cf95b0a793221432750c07a',1,'precond_FASP_blkoil_data::order()']]],
  ['output_5ftype',['output_type',['../structinput__param.html#a78dcb92f2acddaef4acc72c4cc0bba1d',1,'input_param']]]
];
