var searchData=
[
  ['dcsrmat2samginput',['dCSRmat2SAMGInput',['../interface__samg_8c.html#aa5b8bc5d87cae1eebed6828d53e8ccc0',1,'interface_samg.c']]],
  ['dvector2samginput',['dvector2SAMGInput',['../interface__samg_8c.html#a2bbc014a531ed669e3cec20188538a4a',1,'interface_samg.c']]]
];
