var searchData=
[
  ['bigreal',['BIGREAL',['../fasp__const_8h.html#a9457fe109bc3300d1b5b969c1bb30136',1,'fasp_const.h']]]
];
