var searchData=
[
  ['swz_5fdata',['SWZ_data',['../structSWZ__data.html',1,'']]],
  ['swz_5fparam',['SWZ_param',['../structSWZ__param.html',1,'']]]
];
