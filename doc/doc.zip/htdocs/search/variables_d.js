var searchData=
[
  ['quality_5fbound_0',['quality_bound',['../structAMG__param.html#a932e18821a4ef94d5e3b33df734d6f93',1,'AMG_param']]]
];
