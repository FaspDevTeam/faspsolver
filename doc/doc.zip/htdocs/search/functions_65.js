var searchData=
[
  ['enter_5flist',['enter_list',['../coarsening__rs_8c.html#ae113ee796b4433d8d45696f5a361f037',1,'coarsening_rs.c']]]
];
