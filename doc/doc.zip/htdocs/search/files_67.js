var searchData=
[
  ['get_5fnum_5fthreads_2ec',['get_num_threads.c',['../get__num__threads_8c.html',1,'']]],
  ['givens_2ec',['givens.c',['../givens_8c.html',1,'']]],
  ['graphics_2ec',['graphics.c',['../graphics_8c.html',1,'']]]
];
