var searchData=
[
  ['givens_2ec',['givens.c',['../givens_8c.html',1,'']]],
  ['gmg_5futil_2einl',['gmg_util.inl',['../gmg__util_8inl.html',1,'']]],
  ['graphics_2ec',['graphics.c',['../graphics_8c.html',1,'']]]
];
