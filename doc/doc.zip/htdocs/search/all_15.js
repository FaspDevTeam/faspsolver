var searchData=
[
  ['ua_5famg',['UA_AMG',['../fasp__const_8h.html#afd263e443292d581ba90928f142d709a',1,'fasp_const.h']]],
  ['unpt',['UNPT',['../fasp__const_8h.html#a74ea58908bcd4062248c5829f56761c0',1,'fasp_const.h']]],
  ['uptr',['uptr',['../structILU__data.html#ae3b789ccc05c6c578f3c98de558c8fc5',1,'ILU_data']]],
  ['userdefined',['USERDEFINED',['../fasp__const_8h.html#aba2be20c77089257ed00d4081a809097',1,'fasp_const.h']]]
];
