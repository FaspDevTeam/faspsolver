var searchData=
[
  ['descend',['DESCEND',['../fasp__const_8h.html#aae091878711af627f7fafa3f8bdf34bf',1,'fasp_const.h']]],
  ['diagonal_5fpref',['DIAGONAL_PREF',['../fasp_8h.html#aa4e5566466ad9ec9eed600dfa7a9b4c8',1,'fasp.h']]],
  ['dlmalloc',['DLMALLOC',['../fasp_8h.html#aaa7b51dd03b34affb423f16715712010',1,'fasp.h']]]
];
