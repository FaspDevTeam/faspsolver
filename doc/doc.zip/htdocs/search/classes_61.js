var searchData=
[
  ['amg_5fdata',['AMG_data',['../structAMG__data.html',1,'']]],
  ['amg_5fdata_5fbsr',['AMG_data_bsr',['../structAMG__data__bsr.html',1,'']]],
  ['amg_5fparam',['AMG_param',['../structAMG__param.html',1,'']]]
];
