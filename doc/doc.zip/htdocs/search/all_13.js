var searchData=
[
  ['t',['t',['../structgrid2d.html#aa0e476c771c999a96003ecdf3da5286a',1,'grid2d']]],
  ['tail',['tail',['../structlinked__list.html#a76c118c9041a8089b700f2a765427711',1,'linked_list']]],
  ['tentative_5fsmooth',['tentative_smooth',['../structAMG__param.html#a9c0412c02f9b936f4a54fa5b8cc2f11c',1,'AMG_param::tentative_smooth()'],['../structprecond__data.html#a9c0412c02f9b936f4a54fa5b8cc2f11c',1,'precond_data::tentative_smooth()'],['../structprecond__data__bsr.html#a9c0412c02f9b936f4a54fa5b8cc2f11c',1,'precond_data_bsr::tentative_smooth()'],['../structprecond__FASP__blkoil__data.html#a9c0412c02f9b936f4a54fa5b8cc2f11c',1,'precond_FASP_blkoil_data::tentative_smooth()']]],
  ['tfather',['tfather',['../structgrid2d.html#a7785c2c57ce2b2bd47e26568c38f3617',1,'grid2d']]],
  ['thds_5famg_5fgs',['THDs_AMG_GS',['../itsolver__bsr_8c.html#afb208d7828e65b80059a7db51731f9ac',1,'itsolver_bsr.c']]],
  ['thds_5fcpr_5fggs',['THDs_CPR_gGS',['../itsolver__bsr_8c.html#a255e66195f154aeed42d772a5e5738aa',1,'itsolver_bsr.c']]],
  ['thds_5fcpr_5flgs',['THDs_CPR_lGS',['../itsolver__bsr_8c.html#a8ff6f13cf7a93586b4e66fc601e75077',1,'itsolver_bsr.c']]],
  ['threads_2ec',['threads.c',['../threads_8c.html',1,'']]],
  ['timing_2ec',['timing.c',['../timing_8c.html',1,'']]],
  ['tol',['tol',['../structAMG__param.html#a76a01e9ce9eb7e3d48653fffe3b6962e',1,'AMG_param::tol()'],['../structprecond__data.html#a76a01e9ce9eb7e3d48653fffe3b6962e',1,'precond_data::tol()'],['../structprecond__data__str.html#a76a01e9ce9eb7e3d48653fffe3b6962e',1,'precond_data_str::tol()'],['../structitsolver__param.html#a76a01e9ce9eb7e3d48653fffe3b6962e',1,'itsolver_param::tol()'],['../structprecond__data__bsr.html#a76a01e9ce9eb7e3d48653fffe3b6962e',1,'precond_data_bsr::tol()'],['../structprecond__block__reservoir__data.html#a76a01e9ce9eb7e3d48653fffe3b6962e',1,'precond_block_reservoir_data::tol()'],['../structprecond__FASP__blkoil__data.html#a76a01e9ce9eb7e3d48653fffe3b6962e',1,'precond_FASP_blkoil_data::tol()']]],
  ['total_5falloc_5fcount',['total_alloc_count',['../fasp_8h.html#a8b14f3bf80619e4909f60d0a75b1b2c8',1,'total_alloc_count():&#160;memory.c'],['../memory_8c.html#a8b14f3bf80619e4909f60d0a75b1b2c8',1,'total_alloc_count():&#160;memory.c']]],
  ['total_5falloc_5fmem',['total_alloc_mem',['../fasp_8h.html#a790fccbaed2f636a73e45611e0c657c9',1,'total_alloc_mem():&#160;memory.c'],['../memory_8c.html#a790fccbaed2f636a73e45611e0c657c9',1,'total_alloc_mem():&#160;memory.c']]],
  ['triangles',['triangles',['../structgrid2d.html#a3e3d0fff8b5ed5a478b138678662cf84',1,'grid2d']]],
  ['true',['TRUE',['../fasp__const_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'fasp_const.h']]],
  ['truncation_5fthreshold',['truncation_threshold',['../structAMG__param.html#ad2d6c5dbb555a20092017ea0d51bb624',1,'AMG_param']]]
];
