var searchData=
[
  ['generate_5fs_5frs',['generate_S_rs',['../coarsening__rs_8c.html#a13f77368fbe974b9414999d47e5fd26b',1,'coarsening_rs.c']]]
];
