var searchData=
[
  ['schwarz_5fdata',['Schwarz_data',['../structSchwarz__data.html',1,'']]],
  ['schwarz_5fparam',['Schwarz_param',['../structSchwarz__param.html',1,'']]]
];
