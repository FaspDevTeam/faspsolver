var searchData=
[
  ['x_1046',['x',['../structAMG__data.html#abc14393d10a69508c5f56f85abd6670c',1,'AMG_data::x()'],['../structAMG__data__bsr.html#abc14393d10a69508c5f56f85abd6670c',1,'AMG_data_bsr::x()']]],
  ['xloc1_1047',['xloc1',['../structSWZ__data.html#a6774a4ebc40deaf07352694a56300dca',1,'SWZ_data']]],
  ['xtrmumps_2ec_1048',['XtrMumps.c',['../XtrMumps_8c.html',1,'']]],
  ['xtrpardiso_2ec_1049',['XtrPardiso.c',['../XtrPardiso_8c.html',1,'']]],
  ['xtrsamg_2ec_1050',['XtrSamg.c',['../XtrSamg_8c.html',1,'']]],
  ['xtrsuperlu_2ec_1051',['XtrSuperlu.c',['../XtrSuperlu_8c.html',1,'']]],
  ['xtrumfpack_2ec_1052',['XtrUmfpack.c',['../XtrUmfpack_8c.html',1,'']]]
];
