var searchData=
[
  ['write_5fbmp16',['write_bmp16',['../graphics_8c.html#ae8c737d9415f60767d264f0ab47649cd',1,'graphics.c']]]
];
