var searchData=
[
  ['nedpool_5ft',['nedpool_t',['../structnedpool__t.html',1,'']]]
];
