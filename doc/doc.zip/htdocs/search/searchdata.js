var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwx",
  1: "abdgimps",
  2: "abdfikpsx",
  3: "df",
  4: "abcdefijlmnopqrstuvwx",
  5: "bdgip",
  6: "_abcdefgilmnoprstuvw",
  7: "bdhi"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros",
  7: "Pages"
};

