var amg__setup__sa_8c =
[
    [ "fasp_amg_setup_sa", "amg__setup__sa_8c.html#acf8f82a2ecd81656f0137b513e9fe8d2", null ],
    [ "fasp_amg_setup_sa_bsr", "amg__setup__sa_8c.html#a1998cc83b8e8fd3fca99211225f18362", null ]
];