var amg__setup__sa_8c =
[
    [ "amg_setup_smoothP_smoothA", "amg__setup__sa_8c.html#ab93488bc56a3230000fdea8b13c24a2b", null ],
    [ "amg_setup_smoothP_unsmoothA", "amg__setup__sa_8c.html#a04fcae8dd5f64a16a1b0412ee83db956", null ],
    [ "fasp_amg_setup_sa", "amg__setup__sa_8c.html#acf8f82a2ecd81656f0137b513e9fe8d2", null ],
    [ "smooth_agg", "amg__setup__sa_8c.html#a5c245a8d083c628bab637ee2015c60cd", null ]
];