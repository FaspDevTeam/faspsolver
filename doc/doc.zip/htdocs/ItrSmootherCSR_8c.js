var ItrSmootherCSR_8c =
[
    [ "fasp_smoother_dcsr_gs", "ItrSmootherCSR_8c.html#aa3abf83a9d9f4deaa75b229ff485d67b", null ],
    [ "fasp_smoother_dcsr_gs_cf", "ItrSmootherCSR_8c.html#af6d8a0e713065cda43a9c6a71a2f9b01", null ],
    [ "fasp_smoother_dcsr_ilu", "ItrSmootherCSR_8c.html#abe3341adbcbaa35ed9d11c0c26e35e66", null ],
    [ "fasp_smoother_dcsr_jacobi", "ItrSmootherCSR_8c.html#af06c523b3e792b20f6f308e79ce2fa00", null ],
    [ "fasp_smoother_dcsr_kaczmarz", "ItrSmootherCSR_8c.html#a50b4e4e30d94483de5dd7181e27bf6fe", null ],
    [ "fasp_smoother_dcsr_L1diag", "ItrSmootherCSR_8c.html#ac8467101d84f35d96ffac0ab1c54e477", null ],
    [ "fasp_smoother_dcsr_sgs", "ItrSmootherCSR_8c.html#a7380ea2fd9a33f314d00a93e996cd8f7", null ],
    [ "fasp_smoother_dcsr_sor", "ItrSmootherCSR_8c.html#a3b6d3790562daa013233825774bdf953", null ],
    [ "fasp_smoother_dcsr_sor_cf", "ItrSmootherCSR_8c.html#a08c9c16c5a294138a81c08ddcae45dd8", null ]
];