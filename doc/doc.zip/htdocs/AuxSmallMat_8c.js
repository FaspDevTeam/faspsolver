var AuxSmallMat_8c =
[
    [ "SWAP", "AuxSmallMat_8c.html#aac9153aee4bdb92701df902e06a74eb3", null ],
    [ "fasp_blas_smat_inv", "AuxSmallMat_8c.html#a64c5ac64841555d5516406810f129eca", null ],
    [ "fasp_blas_smat_inv_nc", "AuxSmallMat_8c.html#ae342f3b0ad6b53457091b47ea0d10c0c", null ],
    [ "fasp_blas_smat_inv_nc2", "AuxSmallMat_8c.html#ae7c1378bb6bad8533ac7d132de0c22b0", null ],
    [ "fasp_blas_smat_inv_nc3", "AuxSmallMat_8c.html#a14c79c587f62edf86f14af7f75aaf66a", null ],
    [ "fasp_blas_smat_inv_nc4", "AuxSmallMat_8c.html#a1f246ce2f0d4aa2e65d219cc75251d5a", null ],
    [ "fasp_blas_smat_inv_nc5", "AuxSmallMat_8c.html#afa97e69467335afe3b4b95bb97c8017e", null ],
    [ "fasp_blas_smat_inv_nc7", "AuxSmallMat_8c.html#ae48b2dbdba406fe0f2b22e27964ae3d7", null ],
    [ "fasp_blas_smat_invp_nc", "AuxSmallMat_8c.html#abbba7eac657216f8ed24cc00b3bc56cd", null ],
    [ "fasp_blas_smat_Linfinity", "AuxSmallMat_8c.html#a87865895a66c820d54cf0df77518dba8", null ],
    [ "fasp_iden_free", "AuxSmallMat_8c.html#aa04993ce0277db9b84d3948a3ce9f931", null ],
    [ "fasp_smat_identity", "AuxSmallMat_8c.html#affc43ed3740bc68b8244768d4d408423", null ],
    [ "fasp_smat_identity_nc2", "AuxSmallMat_8c.html#aef3066d4d6bf4424ae19adf212082c35", null ],
    [ "fasp_smat_identity_nc3", "AuxSmallMat_8c.html#a8f15df4ff38748a5c3f96d30c1b3bd5f", null ],
    [ "fasp_smat_identity_nc5", "AuxSmallMat_8c.html#af7adf8914fd48943755a0bb889b2857b", null ],
    [ "fasp_smat_identity_nc7", "AuxSmallMat_8c.html#a584249c0174420c265b587e0e1fee004", null ]
];