var structidenmat =
[
    [ "col", "structidenmat.html#a35e7c2cd24fb4171cce3d78cd8bb3a23", null ],
    [ "row", "structidenmat.html#a741a152c7b18c401af249dfb3a113c95", null ],
    [ "val", "structidenmat.html#ad2d43d5c1df1fb2a1fde3a5356c368ee", null ]
];