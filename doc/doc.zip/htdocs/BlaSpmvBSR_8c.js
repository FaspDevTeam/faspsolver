var BlaSpmvBSR_8c =
[
    [ "fasp_blas_dbsr_aAxpby", "BlaSpmvBSR_8c.html#a8542fba1e49fa346a457785979e6bd08", null ],
    [ "fasp_blas_dbsr_aAxpy", "BlaSpmvBSR_8c.html#abfc5c87d546ef990d345d3b00c4774c2", null ],
    [ "fasp_blas_dbsr_aAxpy_agg", "BlaSpmvBSR_8c.html#ade4e818ca9c0a6660b8734065677c6e3", null ],
    [ "fasp_blas_dbsr_axm", "BlaSpmvBSR_8c.html#a21d3944c110c5912d0f8d289c8e7e854", null ],
    [ "fasp_blas_dbsr_mxm", "BlaSpmvBSR_8c.html#a5af73ff17e99a2a24f8b871c12c71ac5", null ],
    [ "fasp_blas_dbsr_mxv", "BlaSpmvBSR_8c.html#ac911f239311bce3aa86d2e67459a346b", null ],
    [ "fasp_blas_dbsr_mxv_agg", "BlaSpmvBSR_8c.html#a85ff8cc1d79ef12d30939e417ecaa189", null ],
    [ "fasp_blas_dbsr_rap", "BlaSpmvBSR_8c.html#af275a8955343371e6d7825f98ec43ed4", null ],
    [ "fasp_blas_dbsr_rap1", "BlaSpmvBSR_8c.html#a0cd1fd5aed6803f627346735bf69df45", null ],
    [ "fasp_blas_dbsr_rap_agg", "BlaSpmvBSR_8c.html#a619ca38e39883a57286c36b321ab872c", null ]
];