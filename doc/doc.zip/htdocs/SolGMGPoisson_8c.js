var SolGMGPoisson_8c =
[
    [ "fasp_poisson_fgmg1d", "SolGMGPoisson_8c.html#a2f7320a978b1c6fb63b2f4bbcd931207", null ],
    [ "fasp_poisson_fgmg2d", "SolGMGPoisson_8c.html#a39b9b473a52110831f666be0d7779d25", null ],
    [ "fasp_poisson_fgmg3d", "SolGMGPoisson_8c.html#a72c29d27ba087dcf23414a9480cb9dc4", null ],
    [ "fasp_poisson_gmg1d", "SolGMGPoisson_8c.html#a709c84330d83dc2076f0e1608ca29efa", null ],
    [ "fasp_poisson_gmg2d", "SolGMGPoisson_8c.html#a1d644b3a8dbcfdc7eb10753cebc7c732", null ],
    [ "fasp_poisson_gmg3d", "SolGMGPoisson_8c.html#aa6d0275f569359adfbbc6536d9ca6f3f", null ],
    [ "fasp_poisson_gmgcg1d", "SolGMGPoisson_8c.html#a899319b60cc718ca4f689f8214bf7bec", null ],
    [ "fasp_poisson_gmgcg2d", "SolGMGPoisson_8c.html#aabfaf6c59515c87a0329e92b615d03e7", null ],
    [ "fasp_poisson_gmgcg3d", "SolGMGPoisson_8c.html#a2397435be7577e4369dddb596f5d0a13", null ]
];