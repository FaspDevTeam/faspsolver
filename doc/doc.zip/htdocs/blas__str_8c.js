var blas__str_8c =
[
    [ "blkcontr_str", "blas__str_8c.html#a05107d29554d3d58ed998e2ea0c6275d", null ],
    [ "fasp_blas_dstr_aAxpy", "blas__str_8c.html#ac61b1653b723f1744ab560d659f38fa0", null ],
    [ "fasp_dstr_diagscale", "blas__str_8c.html#a41d2c7395d56cdbb55ac4cedbc94bc0f", null ],
    [ "smat_amxv", "blas__str_8c.html#a5ab8ea1424efd017f55581eaf79ce959", null ],
    [ "smat_amxv_nc3", "blas__str_8c.html#a72b189e5f6e9dc95a14dceeb006010f8", null ],
    [ "smat_amxv_nc5", "blas__str_8c.html#a7606721b35d0544b7f27743252217d6c", null ],
    [ "spaaxpy_str_2D_block", "blas__str_8c.html#a946e242569cb4695aa69153a5ea5b8a9", null ],
    [ "spaaxpy_str_2D_nc3", "blas__str_8c.html#a5a2c613e637c01129c015c3c95a105c1", null ],
    [ "spaaxpy_str_2D_nc5", "blas__str_8c.html#a6a08ed30d4ba82b8d265254399eedfd0", null ],
    [ "spaaxpy_str_2D_scalar", "blas__str_8c.html#ace8e5954631af71bd9f65dfa4a169513", null ],
    [ "spaaxpy_str_3D_block", "blas__str_8c.html#a1c00fb684a5a70f389c15c6a9d45c84b", null ],
    [ "spaaxpy_str_3D_nc3", "blas__str_8c.html#a4dad4b6990695d17f9feb6cea5781aab", null ],
    [ "spaaxpy_str_3D_nc5", "blas__str_8c.html#a3df759bdeb448e861114c3000dcb5710", null ],
    [ "spaaxpy_str_3D_scalar", "blas__str_8c.html#a1f7a206f8d3cfbf5b35085696efa1c12", null ],
    [ "spaaxpy_str_general", "blas__str_8c.html#a46ca329dfdc8866d7ab23265f5404bae", null ]
];