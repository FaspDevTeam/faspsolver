var memory_8c =
[
    [ "fasp_mem_calloc", "memory_8c.html#a0e0439e5cc49d7a1ed22008ed4de0cab", null ],
    [ "fasp_mem_check", "memory_8c.html#aa52bf7abb0a344d256de4f7bc0bdee99", null ],
    [ "fasp_mem_dcsr_check", "memory_8c.html#aefd52bfd193615f40f4ab7604e4eb2b1", null ],
    [ "fasp_mem_free", "memory_8c.html#a1ec34a015326b359992c2424269cc048", null ],
    [ "fasp_mem_iludata_check", "memory_8c.html#a6deaf00a35d7f824a0e697b69f2245d8", null ],
    [ "fasp_mem_realloc", "memory_8c.html#a3e76cef9a8cb24ab34d2a07cfb4849e9", null ],
    [ "fasp_mem_usage", "memory_8c.html#af00b5dac654acbf25a8d6895a6e9983f", null ],
    [ "total_alloc_count", "memory_8c.html#a8b14f3bf80619e4909f60d0a75b1b2c8", null ],
    [ "total_alloc_mem", "memory_8c.html#a790fccbaed2f636a73e45611e0c657c9", null ]
];