var structITS__param =
[
    [ "decoup_type", "structITS__param.html#a8b4cf9cc775442d790564a395e0a4725", null ],
    [ "itsolver_type", "structITS__param.html#a0a5874edde02a4db3277b5911204893a", null ],
    [ "maxit", "structITS__param.html#af611c2bf78bd31105bcc3e241b12e549", null ],
    [ "precond_type", "structITS__param.html#a6f04d0c906041ccc1891e5ee49a4b443", null ],
    [ "print_level", "structITS__param.html#a29a57f89daa78e58e74d262209e9cf77", null ],
    [ "restart", "structITS__param.html#a908cd96a1335870bfd78c43dd940052d", null ],
    [ "stop_type", "structITS__param.html#acd5ba946e75eafc547d8b280fba94a9e", null ],
    [ "tol", "structITS__param.html#a76a01e9ce9eb7e3d48653fffe3b6962e", null ]
];