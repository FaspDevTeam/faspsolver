var AuxSort_8c =
[
    [ "fasp_aux_dQuickSort", "AuxSort_8c.html#aaf463fc61af8bb19262b862f3f6f4a38", null ],
    [ "fasp_aux_dQuickSortIndex", "AuxSort_8c.html#a9b86416aee75bae08b2b5de402356ac5", null ],
    [ "fasp_aux_iQuickSort", "AuxSort_8c.html#ab086dc830a83c1fa1cd5938801a9ef4e", null ],
    [ "fasp_aux_iQuickSortIndex", "AuxSort_8c.html#a4702dc827e3fd7b521ef285da64c06c3", null ],
    [ "fasp_aux_merge", "AuxSort_8c.html#a78a4d4fb679dbe6456391209d0e1553e", null ],
    [ "fasp_aux_msort", "AuxSort_8c.html#a86c8e1be37b2fba80320d770e6da8949", null ],
    [ "fasp_aux_unique", "AuxSort_8c.html#afbb22b17f0f8ec7e4eae9f0db9ec697a", null ],
    [ "fasp_BinarySearch", "AuxSort_8c.html#a496b72750e5ba6196f3b962e79b236cf", null ],
    [ "fasp_multicolors_independent_set", "AuxSort_8c.html#a30979b7534e4277a9fff663e3cd5f9f2", null ],
    [ "fasp_topological_sorting_ilu", "AuxSort_8c.html#a6f73bdd7af49eba3acb6376341ab3a8a", null ]
];