var AuxSort_8c =
[
    [ "fasp_aux_BiSearch", "AuxSort_8c.html#a360e2ccac8862aa4f11b15768820aea2", null ],
    [ "fasp_aux_dQuickSort", "AuxSort_8c.html#aaf463fc61af8bb19262b862f3f6f4a38", null ],
    [ "fasp_aux_dQuickSortIndex", "AuxSort_8c.html#a9b86416aee75bae08b2b5de402356ac5", null ],
    [ "fasp_aux_iQuickSort", "AuxSort_8c.html#ab086dc830a83c1fa1cd5938801a9ef4e", null ],
    [ "fasp_aux_iQuickSortIndex", "AuxSort_8c.html#a4702dc827e3fd7b521ef285da64c06c3", null ],
    [ "fasp_aux_merge", "AuxSort_8c.html#a78a4d4fb679dbe6456391209d0e1553e", null ],
    [ "fasp_aux_msort", "AuxSort_8c.html#a86c8e1be37b2fba80320d770e6da8949", null ],
    [ "fasp_aux_unique", "AuxSort_8c.html#afbb22b17f0f8ec7e4eae9f0db9ec697a", null ]
];