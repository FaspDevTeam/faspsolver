var structdBLCmat =
[
    [ "bcol", "structdBLCmat.html#aa72f0e4b562f9818797596099fb8ac41", null ],
    [ "blocks", "structdBLCmat.html#a7327f8619a03f7573ce011259cf8ff12", null ],
    [ "brow", "structdBLCmat.html#a0c327386c4e9c982b15bcc8726a16dd6", null ]
];