var ilu__setup__bsr_8c =
[
    [ "fasp_ilu_dbsr_setup", "ilu__setup__bsr_8c.html#a956ba439787af31ab4073acae2e47694", null ],
    [ "numfac_bsr", "ilu__setup__bsr_8c.html#a6a46c81fa833b029a4b541588d2c0ac1", null ],
    [ "symbfactor_", "ilu__setup__bsr_8c.html#a3b17f07a1ce992b3d734877f219096c4", null ]
];