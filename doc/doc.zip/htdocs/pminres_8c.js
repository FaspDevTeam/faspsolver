var pminres_8c =
[
    [ "fasp_solver_bdcsr_pminres", "pminres_8c.html#adc027867c85bafd3910718aab58416be", null ],
    [ "fasp_solver_dcsr_pminres", "pminres_8c.html#ae814ee00151f613091f11d42f06a711b", null ]
];