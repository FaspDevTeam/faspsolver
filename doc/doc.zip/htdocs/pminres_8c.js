var pminres_8c =
[
    [ "fasp_solver_bdcsr_pminres", "pminres_8c.html#a3e71141635263260dfca253eb47866ad", null ],
    [ "fasp_solver_dcsr_pminres", "pminres_8c.html#aa25ff88ad6254bf14bc217fefb53b35d", null ],
    [ "fasp_solver_dstr_pminres", "pminres_8c.html#afa96fcedf45b5eda17b5d5928b3af768", null ]
];