var BlaSpmvBLC_8c =
[
    [ "fasp_blas_dblc_aAxpy", "BlaSpmvBLC_8c.html#a94eece74eeeb9e0401e232f9c6ab2ee2", null ],
    [ "fasp_blas_dblc_mxv", "BlaSpmvBLC_8c.html#a1a3dc0b810ee012dd192a67e2891665a", null ]
];