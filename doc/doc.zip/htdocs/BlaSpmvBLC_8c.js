var BlaSpmvBLC_8c =
[
    [ "fasp_blas_dblc_aAxpy", "BlaSpmvBLC_8c.html#ae6f6ecda804974a14bff2604725a4e83", null ],
    [ "fasp_blas_dblc_mxv", "BlaSpmvBLC_8c.html#a3b98bea4c48166a695bfb1084795d287", null ]
];