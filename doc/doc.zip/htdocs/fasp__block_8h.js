var fasp__block_8h =
[
    [ "dBSRmat", "structdBSRmat.html", "structdBSRmat" ],
    [ "dBLCmat", "structdBLCmat.html", "structdBLCmat" ],
    [ "iBLCmat", "structiBLCmat.html", "structiBLCmat" ],
    [ "block_dvector", "structblock__dvector.html", "structblock__dvector" ],
    [ "block_ivector", "structblock__ivector.html", "structblock__ivector" ],
    [ "AMG_data_bsr", "structAMG__data__bsr.html", "structAMG__data__bsr" ],
    [ "precond_diag_bsr", "structprecond__diag__bsr.html", "structprecond__diag__bsr" ],
    [ "precond_data_bsr", "structprecond__data__bsr.html", "structprecond__data__bsr" ],
    [ "precond_data_blc", "structprecond__data__blc.html", "structprecond__data__blc" ],
    [ "precond_data_sweeping", "structprecond__data__sweeping.html", "structprecond__data__sweeping" ],
    [ "__FASPBLOCK_HEADER__", "fasp__block_8h.html#aee9c3718795a97070ae2cf90bab99870", null ],
    [ "block_dvector", "fasp__block_8h.html#adb1e4816a5912ed7f6e023f6676091c3", null ],
    [ "block_ivector", "fasp__block_8h.html#a53f72f86b3b57a17f432d2802cdf9e7d", null ],
    [ "dBLCmat", "fasp__block_8h.html#a4f3b47ed6b8f7141d447c5a7794be031", null ],
    [ "dBSRmat", "fasp__block_8h.html#a3e1ec7c4061cef5d64f6fee041177b3a", null ],
    [ "iBLCmat", "fasp__block_8h.html#aaaee637e278849d51b968c5025b32a89", null ]
];