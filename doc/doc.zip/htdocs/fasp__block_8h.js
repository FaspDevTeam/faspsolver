var fasp__block_8h =
[
    [ "dBSRmat", "structdBSRmat.html", "structdBSRmat" ],
    [ "dBLCmat", "structdBLCmat.html", "structdBLCmat" ],
    [ "iBLCmat", "structiBLCmat.html", "structiBLCmat" ],
    [ "block_dvector", "structblock__dvector.html", "structblock__dvector" ],
    [ "block_ivector", "structblock__ivector.html", "structblock__ivector" ],
    [ "AMG_data_bsr", "structAMG__data__bsr.html", "structAMG__data__bsr" ],
    [ "precond_diag_bsr", "structprecond__diag__bsr.html", "structprecond__diag__bsr" ],
    [ "precond_data_bsr", "structprecond__data__bsr.html", "structprecond__data__bsr" ],
    [ "precond_block_data", "structprecond__block__data.html", "structprecond__block__data" ],
    [ "precond_sweeping_data", "structprecond__sweeping__data.html", "structprecond__sweeping__data" ],
    [ "__FASPBLOCK_HEADER__", "fasp__block_8h.html#aee9c3718795a97070ae2cf90bab99870", null ],
    [ "block_dvector", "fasp__block_8h.html#adddfc2e04d46b626669d27f34b9ef032", null ],
    [ "block_ivector", "fasp__block_8h.html#ae0755b0aff70990c951030297946ee4a", null ],
    [ "dBLCmat", "fasp__block_8h.html#a5c38ef3984eba70f915bbf9203a3de95", null ],
    [ "dBSRmat", "fasp__block_8h.html#aa44a2fae1d82b08c3b0ce34d3e8dc576", null ],
    [ "iBLCmat", "fasp__block_8h.html#ad53b7b34a6002b2530c57bba33a940b0", null ]
];