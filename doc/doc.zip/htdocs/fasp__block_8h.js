var fasp__block_8h =
[
    [ "dBSRmat", "structdBSRmat.html", "structdBSRmat" ],
    [ "block_dCSRmat", "structblock__dCSRmat.html", "structblock__dCSRmat" ],
    [ "block_iCSRmat", "structblock__iCSRmat.html", "structblock__iCSRmat" ],
    [ "block_dvector", "structblock__dvector.html", "structblock__dvector" ],
    [ "block_ivector", "structblock__ivector.html", "structblock__ivector" ],
    [ "block_Reservoir", "structblock__Reservoir.html", "structblock__Reservoir" ],
    [ "block_BSR", "structblock__BSR.html", "structblock__BSR" ],
    [ "AMG_data_bsr", "structAMG__data__bsr.html", "structAMG__data__bsr" ],
    [ "precond_data_bsr", "structprecond__data__bsr.html", "structprecond__data__bsr" ],
    [ "precond_block_reservoir_data", "structprecond__block__reservoir__data.html", "structprecond__block__reservoir__data" ],
    [ "precond_block_data", "structprecond__block__data.html", "structprecond__block__data" ],
    [ "precond_FASP_blkoil_data", "structprecond__FASP__blkoil__data.html", "structprecond__FASP__blkoil__data" ],
    [ "__FASPBLOCK_HEADER__", "fasp__block_8h.html#aee9c3718795a97070ae2cf90bab99870", null ],
    [ "block_BSR", "fasp__block_8h.html#a84755e45fefdd4e0b01f1bc3c1539e45", null ],
    [ "block_dCSRmat", "fasp__block_8h.html#a385861710addc9588d806060bda8e566", null ],
    [ "block_dvector", "fasp__block_8h.html#adddfc2e04d46b626669d27f34b9ef032", null ],
    [ "block_iCSRmat", "fasp__block_8h.html#a431e53d1892f0ea1ca96f669944be454", null ],
    [ "block_ivector", "fasp__block_8h.html#ae0755b0aff70990c951030297946ee4a", null ],
    [ "block_Reservoir", "fasp__block_8h.html#aacef4ade58c89c2972c322c4d463a429", null ],
    [ "dBSRmat", "fasp__block_8h.html#aa44a2fae1d82b08c3b0ce34d3e8dc576", null ],
    [ "precond_block_reservoir_data", "fasp__block_8h.html#a2997888a40db82f05ae899e3e4369dfe", null ]
];