var BlaSparseBSR_8c =
[
    [ "fasp_dbsr_alloc", "BlaSparseBSR_8c.html#a6abcff130aa2121a2ca2e6505c5e06a2", null ],
    [ "fasp_dbsr_cp", "BlaSparseBSR_8c.html#a4e24038e0c9ac2a0a52b026ee551db6b", null ],
    [ "fasp_dbsr_create", "BlaSparseBSR_8c.html#a003355dd1c713a92f3b81207b870a230", null ],
    [ "fasp_dbsr_diaginv", "BlaSparseBSR_8c.html#a18aa9992ba6714b7168a2334cdca31e3", null ],
    [ "fasp_dbsr_diaginv2", "BlaSparseBSR_8c.html#a99333691f81e40be4c01843feff7b0ee", null ],
    [ "fasp_dbsr_diaginv3", "BlaSparseBSR_8c.html#aefa61464285151f616ffc0394b967b02", null ],
    [ "fasp_dbsr_diaginv4", "BlaSparseBSR_8c.html#ac1b768525bcb2fff9b9107d22fa1caf6", null ],
    [ "fasp_dbsr_diagLU", "BlaSparseBSR_8c.html#a47335e6ac643c00b21e926663efea9a9", null ],
    [ "fasp_dbsr_diagLU2", "BlaSparseBSR_8c.html#a5043068beb521d3f4f03d4aa9b3017de", null ],
    [ "fasp_dbsr_diagpref", "BlaSparseBSR_8c.html#a9bf2775ae6f1a316bcf069142ba92913", null ],
    [ "fasp_dbsr_free", "BlaSparseBSR_8c.html#a704b364dd1ecab8a1eea542aa27edc52", null ],
    [ "fasp_dbsr_getdiag", "BlaSparseBSR_8c.html#a3bc0aa6554fbeea34f67464263f26029", null ],
    [ "fasp_dbsr_getdiaginv", "BlaSparseBSR_8c.html#af0f790c06c9deb45833db06e9301cc51", null ],
    [ "fasp_dbsr_null", "BlaSparseBSR_8c.html#a23a6f5116d0434bf93f66dae82a16c80", null ],
    [ "fasp_dbsr_perm", "BlaSparseBSR_8c.html#a5210beb1c464566f37ebcd501b23c3ab", null ],
    [ "fasp_dbsr_trans", "BlaSparseBSR_8c.html#a3480dc0aeb7ca505b52cdb78a365f7af", null ]
];