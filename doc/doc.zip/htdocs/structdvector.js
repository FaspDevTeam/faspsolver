var structdvector =
[
    [ "row", "structdvector.html#a741a152c7b18c401af249dfb3a113c95", null ],
    [ "val", "structdvector.html#a6e543bb0c5acc1b10ba8e2a72eb92b52", null ]
];