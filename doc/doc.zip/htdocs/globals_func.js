var globals_func =
[
    [ "d", "globals_func.html", null ],
    [ "e", "globals_func_e.html", null ],
    [ "f", "globals_func_f.html", null ],
    [ "p", "globals_func_p.html", null ]
];