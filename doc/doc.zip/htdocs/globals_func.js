var globals_func =
[
    [ "d", "globals_func.html", null ],
    [ "e", "globals_func_0x65.html", null ],
    [ "f", "globals_func_0x66.html", null ],
    [ "i", "globals_func_0x69.html", null ],
    [ "p", "globals_func_0x70.html", null ],
    [ "s", "globals_func_0x73.html", null ]
];