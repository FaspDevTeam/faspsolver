var globals_func =
[
    [ "d", "globals_func.html", null ],
    [ "f", "globals_func_f.html", null ],
    [ "m", "globals_func_m.html", null ],
    [ "t", "globals_func_t.html", null ]
];