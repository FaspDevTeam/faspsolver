var structPardiso__data =
[
    [ "pt", "structPardiso__data.html#ab4df10b7127b77398d85961f89f17182", null ]
];