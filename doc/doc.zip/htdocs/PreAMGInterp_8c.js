var PreAMGInterp_8c =
[
    [ "fasp_amg_interp", "PreAMGInterp_8c.html#a71930a5b931c497e238e92dc88d449c6", null ],
    [ "fasp_amg_interp_trunc", "PreAMGInterp_8c.html#a8e8431c9d78b53a8e156a57c0520914e", null ]
];