var amg__setup__rs_8c =
[
    [ "fasp_amg_setup_rs", "amg__setup__rs_8c.html#aaced509655e600fa218e9e15ecd136d3", null ],
    [ "fasp_amg_setup_rs_omp", "amg__setup__rs_8c.html#af6e82ff972fa7267151a1ef61fc24d44", null ]
];