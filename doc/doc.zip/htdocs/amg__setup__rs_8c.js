var amg__setup__rs_8c =
[
    [ "fasp_amg_setup_rs", "amg__setup__rs_8c.html#a0861271bf1606c05e3a76b4209082869", null ],
    [ "fasp_amg_setup_rs_omp", "amg__setup__rs_8c.html#af6e82ff972fa7267151a1ef61fc24d44", null ]
];