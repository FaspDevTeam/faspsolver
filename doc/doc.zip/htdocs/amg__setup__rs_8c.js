var amg__setup__rs_8c =
[
    [ "dCSRmat_Division_Groups", "amg__setup__rs_8c.html#a430d1f7627e331183569de52c52cff32", null ],
    [ "fasp_amg_setup_rs", "amg__setup__rs_8c.html#a0861271bf1606c05e3a76b4209082869", null ],
    [ "fasp_amg_setup_rs_omp", "amg__setup__rs_8c.html#af6e82ff972fa7267151a1ef61fc24d44", null ]
];