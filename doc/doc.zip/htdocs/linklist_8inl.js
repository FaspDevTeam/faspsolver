var linklist_8inl =
[
    [ "LIST_HEAD", "linklist_8inl.html#a5fc6a15ca26c6208f66ad2768a3108ef", null ],
    [ "LIST_TAIL", "linklist_8inl.html#a745de98bef5b645df56479181803235b", null ]
];