var searchData=
[
  ['i',['I',['../structdCOOmat.html#a18705150686aed6c5e1040c229d11d8c',1,'dCOOmat::I()'],['../structiCOOmat.html#a18705150686aed6c5e1040c229d11d8c',1,'iCOOmat::I()']]],
  ['ia',['IA',['../structdCSRmat.html#a82a122cbfe1b4c4d010a147a0a72ebd1',1,'dCSRmat::IA()'],['../structiCSRmat.html#a82a122cbfe1b4c4d010a147a0a72ebd1',1,'iCSRmat::IA()'],['../structdBSRmat.html#a82a122cbfe1b4c4d010a147a0a72ebd1',1,'dBSRmat::IA()']]],
  ['iblock',['iblock',['../structSchwarz__data.html#af5bf0e94a28b0eced9cf2c915e54ab86',1,'Schwarz_data']]],
  ['ijlu',['ijlu',['../structILU__data.html#a107bcaa8659bfc0f9cd64c8125d51867',1,'ILU_data']]],
  ['ilu_5fdroptol',['ILU_droptol',['../structILU__param.html#a98c24505c01afe05fe4389f16a84ea73',1,'ILU_param::ILU_droptol()'],['../structAMG__param.html#a98c24505c01afe05fe4389f16a84ea73',1,'AMG_param::ILU_droptol()'],['../structinput__param.html#a98c24505c01afe05fe4389f16a84ea73',1,'input_param::ILU_droptol()']]],
  ['ilu_5flevels',['ILU_levels',['../structAMG__param.html#a6782ff6619a9c6c59bfb0bf1c4077758',1,'AMG_param::ILU_levels()'],['../structAMG__data.html#aa5c8d733deaf3a804ac7462e5a3ab21e',1,'AMG_data::ILU_levels()'],['../structAMG__data__bsr.html#aa5c8d733deaf3a804ac7462e5a3ab21e',1,'AMG_data_bsr::ILU_levels()']]],
  ['ilu_5flfil',['ILU_lfil',['../structILU__param.html#a0acf9f67e0ee65774534b25d987824d6',1,'ILU_param::ILU_lfil()'],['../structAMG__param.html#a0acf9f67e0ee65774534b25d987824d6',1,'AMG_param::ILU_lfil()'],['../structinput__param.html#a0acf9f67e0ee65774534b25d987824d6',1,'input_param::ILU_lfil()'],['../structprecond__block__reservoir__data.html#a0acf9f67e0ee65774534b25d987824d6',1,'precond_block_reservoir_data::ILU_lfil()']]],
  ['ilu_5fpermtol',['ILU_permtol',['../structILU__param.html#aeadd62bfc8d57238fcde97ae14b35ffe',1,'ILU_param::ILU_permtol()'],['../structAMG__param.html#aeadd62bfc8d57238fcde97ae14b35ffe',1,'AMG_param::ILU_permtol()'],['../structinput__param.html#aeadd62bfc8d57238fcde97ae14b35ffe',1,'input_param::ILU_permtol()']]],
  ['ilu_5frelax',['ILU_relax',['../structILU__param.html#a18a8038212e6b62f7651dab319f16c16',1,'ILU_param::ILU_relax()'],['../structAMG__param.html#a18a8038212e6b62f7651dab319f16c16',1,'AMG_param::ILU_relax()'],['../structinput__param.html#a18a8038212e6b62f7651dab319f16c16',1,'input_param::ILU_relax()']]],
  ['ilu_5ftype',['ILU_type',['../structILU__param.html#a8d76e6308491d63b4e8a720bfe444e6c',1,'ILU_param::ILU_type()'],['../structAMG__param.html#a8d76e6308491d63b4e8a720bfe444e6c',1,'AMG_param::ILU_type()'],['../structinput__param.html#a8d76e6308491d63b4e8a720bfe444e6c',1,'input_param::ILU_type()']]],
  ['interpolation_5ftype',['interpolation_type',['../structAMG__param.html#a27282eea92a5bdcb592264bb61572415',1,'AMG_param']]],
  ['invs',['invS',['../structprecond__block__reservoir__data.html#a58b1edf03ea673a3f357a78842466f3b',1,'precond_block_reservoir_data::invS()'],['../structprecond__FASP__blkoil__data.html#a58b1edf03ea673a3f357a78842466f3b',1,'precond_FASP_blkoil_data::invS()']]],
  ['itsolver_5fmaxit',['itsolver_maxit',['../structinput__param.html#abfbb97444d0be88b76d373dd971b372b',1,'input_param']]],
  ['itsolver_5ftol',['itsolver_tol',['../structinput__param.html#aee0c3ad67bec6d73d60b31c3bc6573e7',1,'input_param']]],
  ['itsolver_5ftype',['itsolver_type',['../structitsolver__param.html#a0a5874edde02a4db3277b5911204893a',1,'itsolver_param']]]
];
