var searchData=
[
  ['write_5fbmp16',['write_bmp16',['../graphics_8c.html#ab1bbf6c66b8bf9dce141cf96e9cb74fa',1,'graphics.c']]]
];
