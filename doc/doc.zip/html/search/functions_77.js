var searchData=
[
  ['write_5fbmp16',['write_bmp16',['../graphics_8c.html#ab1bbf6c66b8bf9dce141cf96e9cb74fa',1,'graphics.c']]],
  ['write_5fmesh_5finfo',['write_mesh_info',['../poisson__fem_8c.html#a3d6e75b3537e0a7ff698b531889bf6e6',1,'poisson_fem.c']]]
];
