var searchData=
[
  ['ordering_2ec',['ordering.c',['../ordering_8c.html',1,'']]]
];
