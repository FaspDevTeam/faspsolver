var searchData=
[
  ['saaxpby',['saAxpby',['../smoother__str_8c.html#a74a2e762a1315f1265570584c72cb7ac',1,'smoother_str.c']]],
  ['setup_5fpoisson',['setup_poisson',['../poisson__fem_8c.html#a0e7b4f5923aa4b053fdb45a0ee98bab0',1,'setup_poisson(dCSRmat *ptr_A, dvector *ptr_b, int levelNum, const char *meshIn, const char *meshOut, int mo, const char *assemble_option, int num_qp_rhs, int num_qp_mat):&#160;poisson_fem.c'],['../poisson__fem_8h.html#a0e7b4f5923aa4b053fdb45a0ee98bab0',1,'setup_poisson(dCSRmat *ptr_A, dvector *ptr_b, int levelNum, const char *meshIn, const char *meshOut, int mo, const char *assemble_option, int num_qp_rhs, int num_qp_mat):&#160;poisson_fem.c']]],
  ['smat_5famxv',['smat_amxv',['../blas__str_8c.html#a5ab8ea1424efd017f55581eaf79ce959',1,'blas_str.c']]],
  ['smat_5famxv_5fnc5',['smat_amxv_nc5',['../blas__str_8c.html#a7606721b35d0544b7f27743252217d6c',1,'blas_str.c']]],
  ['smooth_5fagg',['smooth_agg',['../amg__setup__sa_8c.html#a5c245a8d083c628bab637ee2015c60cd',1,'amg_setup_sa.c']]],
  ['spaaxpy_5fstr_5f2d_5fblock',['spaaxpy_str_2D_block',['../blas__str_8c.html#a946e242569cb4695aa69153a5ea5b8a9',1,'blas_str.c']]],
  ['spaaxpy_5fstr_5f2d_5fnc3',['spaaxpy_str_2D_nc3',['../blas__str_8c.html#a5a2c613e637c01129c015c3c95a105c1',1,'blas_str.c']]],
  ['spaaxpy_5fstr_5f2d_5fnc5',['spaaxpy_str_2D_nc5',['../blas__str_8c.html#a6a08ed30d4ba82b8d265254399eedfd0',1,'blas_str.c']]],
  ['spaaxpy_5fstr_5f2d_5fscalar',['spaaxpy_str_2D_scalar',['../blas__str_8c.html#ace8e5954631af71bd9f65dfa4a169513',1,'blas_str.c']]],
  ['spaaxpy_5fstr_5f3d_5fblock',['spaaxpy_str_3D_block',['../blas__str_8c.html#a1c00fb684a5a70f389c15c6a9d45c84b',1,'blas_str.c']]],
  ['spaaxpy_5fstr_5f3d_5fnc3',['spaaxpy_str_3D_nc3',['../blas__str_8c.html#a4dad4b6990695d17f9feb6cea5781aab',1,'blas_str.c']]],
  ['spaaxpy_5fstr_5f3d_5fnc5',['spaaxpy_str_3D_nc5',['../blas__str_8c.html#a3df759bdeb448e861114c3000dcb5710',1,'blas_str.c']]],
  ['spaaxpy_5fstr_5f3d_5fscalar',['spaaxpy_str_3D_scalar',['../blas__str_8c.html#a1f7a206f8d3cfbf5b35085696efa1c12',1,'blas_str.c']]],
  ['spaaxpy_5fstr_5fgeneral',['spaaxpy_str_general',['../blas__str_8c.html#a46ca329dfdc8866d7ab23265f5404bae',1,'blas_str.c']]]
];
