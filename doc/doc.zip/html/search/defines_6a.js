var searchData=
[
  ['jacobi',['JACOBI',['../messages_8h.html#a757914ed6297a006d7fd30933340d009',1,'messages.h']]]
];
