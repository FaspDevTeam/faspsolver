var searchData=
[
  ['basisp1',['basisP1',['../basis_8inl.html#abb9ba62a369928dd3e3b5cf2a3dded0f',1,'basis.inl']]],
  ['bd_5fflag',['bd_flag',['../testfct__heat_8inl.html#a68939587626e42198c328331c883fcf9',1,'testfct_heat.inl']]],
  ['blkcontr2_5fstr',['blkcontr2_str',['../smoother__str_8c.html#a5345b3475f7ec0b666f1ec6a090ea95a',1,'smoother_str.c']]],
  ['blkcontr_5fstr',['blkcontr_str',['../blas__str_8c.html#a05107d29554d3d58ed998e2ea0c6275d',1,'blas_str.c']]],
  ['bminax',['bminax',['../smoother__poly_8c.html#a4e6031d603c33da0b0228cf8d461865e',1,'smoother_poly.c']]]
];
