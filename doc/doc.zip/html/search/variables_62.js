var searchData=
[
  ['b',['b',['../structAMG__data.html#a921cb3b9308d321aa1956ca99e2c6a6a',1,'AMG_data::b()'],['../structAMG__data__bsr.html#a921cb3b9308d321aa1956ca99e2c6a6a',1,'AMG_data_bsr::b()']]],
  ['bcol',['bcol',['../structblock__dCSRmat.html#aa72f0e4b562f9818797596099fb8ac41',1,'block_dCSRmat::bcol()'],['../structblock__iCSRmat.html#aa72f0e4b562f9818797596099fb8ac41',1,'block_iCSRmat::bcol()']]],
  ['beta',['beta',['../structprecond__Stokes__data.html#a1ee9fe246c60f81cefab3dc159aa375d',1,'precond_Stokes_data']]],
  ['blocks',['blocks',['../structblock__dCSRmat.html#a7327f8619a03f7573ce011259cf8ff12',1,'block_dCSRmat::blocks()'],['../structblock__iCSRmat.html#a8cea7044158e2bbc32709339144ab0cf',1,'block_iCSRmat::blocks()'],['../structblock__dvector.html#a5c2696b5f63cbf8b3b88d90cf5f6e242',1,'block_dvector::blocks()'],['../structblock__ivector.html#ab53c571e03eaa11827a457509fff582b',1,'block_ivector::blocks()']]],
  ['brow',['brow',['../structblock__dCSRmat.html#a0c327386c4e9c982b15bcc8726a16dd6',1,'block_dCSRmat::brow()'],['../structblock__iCSRmat.html#a0c327386c4e9c982b15bcc8726a16dd6',1,'block_iCSRmat::brow()'],['../structblock__dvector.html#a0c327386c4e9c982b15bcc8726a16dd6',1,'block_dvector::brow()'],['../structblock__ivector.html#a0c327386c4e9c982b15bcc8726a16dd6',1,'block_ivector::brow()']]]
];
