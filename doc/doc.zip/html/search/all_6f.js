var searchData=
[
  ['off',['OFF',['../messages_8h.html#a29e413f6725b2ba32d165ffaa35b01e5',1,'messages.h']]],
  ['offdiag',['offdiag',['../structdSTRmat.html#ad9769afd89d479d98bb9843d08c7f0d9',1,'dSTRmat::offdiag()'],['../structfsls__BandMatrix.html#a88505e29658a65f613c3e61b92cbe0dc',1,'fsls_BandMatrix::offdiag()']]],
  ['offsets',['offsets',['../structdSTRmat.html#a18c718e8123868e8178fcc7ec9265f26',1,'dSTRmat::offsets()'],['../structfsls__BandMatrix.html#ad2182a08b22eed3bb3b0728725841875',1,'fsls_BandMatrix::offsets()']]],
  ['on',['ON',['../messages_8h.html#ad76d1750a6cdeebd506bfcd6752554d2',1,'messages.h']]],
  ['order',['order',['../structprecond__data__str.html#a7a633bb60cf95b0a793221432750c07a',1,'precond_data_str::order()'],['../structprecond__block__reservoir__data.html#a7a633bb60cf95b0a793221432750c07a',1,'precond_block_reservoir_data::order()']]],
  ['ordering_2ec',['ordering.c',['../ordering_8c.html',1,'']]],
  ['orderone',['orderone',['../interpolation_8c.html#acd300e0fc00c2d5441556cecb9be55b1',1,'interpolation.c']]],
  ['output_5ftype',['output_type',['../structinput__param.html#a78dcb92f2acddaef4acc72c4cc0bba1d',1,'input_param']]]
];
