var searchData=
[
  ['print_5fitinfo',['print_itinfo',['../message_8c.html#ad2263a3dbbe05bcf0e0584c7f419c512',1,'print_itinfo(const INT ptrlvl, const INT stop_type, const INT iter, const REAL relres, const REAL absres, const REAL factor):&#160;message.c'],['../fasp__functs_8h.html#ad2263a3dbbe05bcf0e0584c7f419c512',1,'print_itinfo(const INT ptrlvl, const INT stop_type, const INT iter, const REAL relres, const REAL absres, const REAL factor):&#160;message.c']]],
  ['print_5fmessage',['print_message',['../message_8c.html#a1d0e1bff73df43f52402cb0a49492b61',1,'print_message(const INT ptrlvl, const char *message):&#160;message.c'],['../fasp__functs_8h.html#a1d0e1bff73df43f52402cb0a49492b61',1,'print_message(const INT ptrlvl, const char *message):&#160;message.c']]]
];
