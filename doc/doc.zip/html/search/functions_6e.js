var searchData=
[
  ['numfac_5fbsr',['numfac_bsr',['../ilu__setup__bsr_8c.html#a6a46c81fa833b029a4b541588d2c0ac1',1,'ilu_setup_bsr.c']]]
];
