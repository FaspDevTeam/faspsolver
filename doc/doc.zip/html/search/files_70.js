var searchData=
[
  ['parameters_2ec',['parameters.c',['../parameters_8c.html',1,'']]],
  ['pbcgs_2ec',['pbcgs.c',['../pbcgs_8c.html',1,'']]],
  ['pcg_2ec',['pcg.c',['../pcg_8c.html',1,'']]],
  ['pcg_5fomp_2ec',['pcg_omp.c',['../pcg__omp_8c.html',1,'']]],
  ['pgcg_2ec',['pgcg.c',['../pgcg_8c.html',1,'']]],
  ['pgmres_2ec',['pgmres.c',['../pgmres_8c.html',1,'']]],
  ['pminres_2ec',['pminres.c',['../pminres_8c.html',1,'']]],
  ['precond_2ec',['precond.c',['../precond_8c.html',1,'']]],
  ['precond_5fbsr_2ec',['precond_bsr.c',['../precond__bsr_8c.html',1,'']]],
  ['precond_5fbsr_5fomp_2ec',['precond_bsr_omp.c',['../precond__bsr__omp_8c.html',1,'']]],
  ['precond_5fomp_2ec',['precond_omp.c',['../precond__omp_8c.html',1,'']]],
  ['precond_5fstr_2ec',['precond_str.c',['../precond__str_8c.html',1,'']]],
  ['pvfgmres_2ec',['pvfgmres.c',['../pvfgmres_8c.html',1,'']]],
  ['pvgmres_2ec',['pvgmres.c',['../pvgmres_8c.html',1,'']]],
  ['pvgmres_5fomp_2ec',['pvgmres_omp.c',['../pvgmres__omp_8c.html',1,'']]]
];
