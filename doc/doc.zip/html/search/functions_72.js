var searchData=
[
  ['rb0b3d',['rb0b3d',['../smoother__csr__omp_8c.html#adf02f33a9c86fb6e08fdc4a54f52f3fc',1,'smoother_csr_omp.c']]],
  ['remove_5fpoint',['remove_point',['../coarsening__rs_8c.html#a3bcd228f24784d24d426f8d44de280cd',1,'coarsening_rs.c']]]
];
