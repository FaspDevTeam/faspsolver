var searchData=
[
  ['rb0b3d',['rb0b3d',['../smoother__csr__omp_8c.html#adf02f33a9c86fb6e08fdc4a54f52f3fc',1,'smoother_csr_omp.c']]],
  ['remove_5fnode',['remove_node',['../coarsening__rs_8c.html#ae6eb0dda584229458b8efe3c78ea2771',1,'coarsening_rs.c']]],
  ['rr',['Rr',['../smoother__poly_8c.html#a23117bc3cd8e5173fcac20656b5fa51b',1,'smoother_poly.c']]]
];
