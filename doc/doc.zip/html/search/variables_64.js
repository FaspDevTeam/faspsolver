var searchData=
[
  ['data',['data',['../structdCSRLmat.html#a19b70fa77a6c599cd2c52aaa0e17c4ff',1,'dCSRLmat::data()'],['../structprecond.html#a735984d41155bc1032e09bece8f8d66d',1,'precond::data()'],['../structlinked__list.html#a46167794081f1a3b94da3c6385e979f4',1,'linked_list::data()']]],
  ['diag',['diag',['../structdSTRmat.html#a781ad64f97cef4bc66d1e932b64cb030',1,'dSTRmat::diag()'],['../structprecond__diagstr.html#aa2ab1984071b37d6300f7ddcc97c68de',1,'precond_diagstr::diag()'],['../structprecond__diagbsr.html#aa2ab1984071b37d6300f7ddcc97c68de',1,'precond_diagbsr::diag()'],['../structprecond__block__reservoir__data.html#ad712420730616640651a0a547c510fd0',1,'precond_block_reservoir_data::diag()']]],
  ['diaginv',['diaginv',['../structprecond__data__str.html#ad2ff3f7d26a74c17af4a2965f0acd2f6',1,'precond_data_str::diaginv()'],['../structprecond__block__reservoir__data.html#ad2ff3f7d26a74c17af4a2965f0acd2f6',1,'precond_block_reservoir_data::diaginv()'],['../structprecond__FASP__blkoil__data.html#ad2ff3f7d26a74c17af4a2965f0acd2f6',1,'precond_FASP_blkoil_data::diaginv()']]],
  ['diaginv_5fnoscale',['diaginv_noscale',['../structprecond__FASP__blkoil__data.html#a854e98e2bb162a908222d20b87cd3415',1,'precond_FASP_blkoil_data']]],
  ['diaginv_5fs',['diaginv_S',['../structprecond__FASP__blkoil__data.html#a9f6eaaf660a330ddf1d8bd030c3b10bf',1,'precond_FASP_blkoil_data']]],
  ['diaginvs',['diaginvS',['../structprecond__data__str.html#ad4d5bc3fd9c8850ddc012cb8a4638213',1,'precond_data_str::diaginvS()'],['../structprecond__block__reservoir__data.html#ad4d5bc3fd9c8850ddc012cb8a4638213',1,'precond_block_reservoir_data::diaginvS()']]],
  ['dif',['dif',['../structdCSRLmat.html#abe359223493d44177442a883d5ae441e',1,'dCSRLmat']]],
  ['dpsinvdss',['DPSinvDSS',['../structprecond__block__reservoir__data.html#ac0a792a59f32683093a4baec327a1f88',1,'precond_block_reservoir_data']]]
];
