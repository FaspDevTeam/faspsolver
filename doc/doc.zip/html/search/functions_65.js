var searchData=
[
  ['enter_5flist',['enter_list',['../coarsening__rs_8c.html#a68a63e3b0da8dab925a935c3e98ed31f',1,'coarsening_rs.c']]],
  ['extractnondirichletmatrix',['extractNondirichletMatrix',['../assemble_8c.html#accd566c38c81bf18b76aaafa55148eae',1,'assemble.c']]]
];
