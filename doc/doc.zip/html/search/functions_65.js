var searchData=
[
  ['enter_5flist',['enter_list',['../coarsening__rs_8c.html#a68a63e3b0da8dab925a935c3e98ed31f',1,'coarsening_rs.c']]]
];
