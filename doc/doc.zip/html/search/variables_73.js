var searchData=
[
  ['s',['s',['../structgrid2d.html#a8279b80a452a022338f53b299cbee5e2',1,'grid2d']]],
  ['scaled',['scaled',['../structprecond__data__str.html#a45a3c0bdd6215dfca159253235e53aa9',1,'precond_data_str::scaled()'],['../structprecond__block__reservoir__data.html#a45a3c0bdd6215dfca159253235e53aa9',1,'precond_block_reservoir_data::scaled()'],['../structprecond__FASP__blkoil__data.html#a45a3c0bdd6215dfca159253235e53aa9',1,'precond_FASP_blkoil_data::scaled()']]],
  ['smooth_5ffilter',['smooth_filter',['../structAMG__param.html#a58814f110bef09b999e3766d3e9f1fb3',1,'AMG_param']]],
  ['smooth_5forder',['smooth_order',['../structAMG__param.html#afd79f7522993440f524b74c2a2a412c8',1,'AMG_param::smooth_order()'],['../structprecond__data.html#afd79f7522993440f524b74c2a2a412c8',1,'precond_data::smooth_order()'],['../structprecond__data__bsr.html#afd79f7522993440f524b74c2a2a412c8',1,'precond_data_bsr::smooth_order()']]],
  ['smoother',['smoother',['../structAMG__param.html#a8537e5121a9f7a09631973a404068041',1,'AMG_param::smoother()'],['../structprecond__data.html#a8537e5121a9f7a09631973a404068041',1,'precond_data::smoother()'],['../structprecond__data__str.html#a8537e5121a9f7a09631973a404068041',1,'precond_data_str::smoother()'],['../structprecond__data__bsr.html#a8537e5121a9f7a09631973a404068041',1,'precond_data_bsr::smoother()'],['../structprecond__Stokes__data.html#a8537e5121a9f7a09631973a404068041',1,'precond_Stokes_data::smoother()'],['../structprecond__block__reservoir__data.html#a8537e5121a9f7a09631973a404068041',1,'precond_block_reservoir_data::smoother()'],['../structprecond__FASP__blkoil__data.html#a8537e5121a9f7a09631973a404068041',1,'precond_FASP_blkoil_data::smoother()']]],
  ['ss',['SS',['../structprecond__block__reservoir__data.html#a83ee91b62d56b9621be189a09801e11c',1,'precond_block_reservoir_data::SS()'],['../structprecond__FASP__blkoil__data.html#a6dafc70edc96eb1d6abf9475f319dad8',1,'precond_FASP_blkoil_data::SS()']]],
  ['ss_5fstr',['SS_str',['../structprecond__data__str.html#af9629b543e8d7cf7522a2fcb9396bf8b',1,'precond_data_str']]],
  ['stop_5ftype',['stop_type',['../structinput__param.html#acd5ba946e75eafc547d8b280fba94a9e',1,'input_param::stop_type()'],['../structitsolver__param.html#acd5ba946e75eafc547d8b280fba94a9e',1,'itsolver_param::stop_type()']]],
  ['storage_5fmanner',['storage_manner',['../structdBSRmat.html#ae7a5fca4952e68db0abe7ddb40a8e772',1,'dBSRmat']]],
  ['strong_5fcoupled',['strong_coupled',['../structAMG__param.html#a7f519d4de98247e5aea9386837290ebe',1,'AMG_param']]],
  ['strong_5fthreshold',['strong_threshold',['../structAMG__param.html#a1c35bc277621220b72df95c72322cd4c',1,'AMG_param']]]
];
