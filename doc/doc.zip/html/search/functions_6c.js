var searchData=
[
  ['localb',['localb',['../heat__fem_8c.html#a093d992eedd7e42947596e079ee4a871',1,'localb(double(*node)[2], double *b, int num_qp, int nt, double dt):&#160;heat_fem.c'],['../poisson__fem_8c.html#a6f96b316078aa63b205c6cf75605457c',1,'localb(double(*node)[DIM], double *b, int num_qp):&#160;poisson_fem.c']]]
];
