var searchData=
[
  ['localb',['localb',['../poisson__fem_8c.html#a36e418a2edcd479e5529266559481223',1,'poisson_fem.c']]]
];
