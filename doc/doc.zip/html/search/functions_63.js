var searchData=
[
  ['create_5fnode',['create_node',['../coarsening__rs_8c.html#a1f4848f81a6ad1a905890677599f7d6e',1,'coarsening_rs.c']]]
];
