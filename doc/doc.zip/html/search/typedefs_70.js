var searchData=
[
  ['pcgrid2d',['pcgrid2d',['../fasp_8h.html#aa81670cccd5457d617938a3fca44bd1e',1,'fasp.h']]],
  ['pgrid2d',['pgrid2d',['../fasp_8h.html#a91271821fb12be095759d8122090db7a',1,'fasp.h']]],
  ['precond_5fblock_5freservoir_5fdata',['precond_block_reservoir_data',['../fasp__block_8h.html#a2997888a40db82f05ae899e3e4369dfe',1,'fasp_block.h']]],
  ['precond_5ffasp_5fblkoil_5fdata',['precond_FASP_blkoil_data',['../fasp__block_8h.html#a35d7393a5f420c7d7f75cad389c82ac4',1,'fasp_block.h']]]
];
