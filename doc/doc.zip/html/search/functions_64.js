var searchData=
[
  ['dispose_5fnode',['dispose_node',['../coarsening__rs_8c.html#ac5bafe3c53d0002830e7f6ed86ffa49e',1,'coarsening_rs.c']]],
  ['dswapping',['dSwapping',['../ordering_8c.html#afca6748aea4d52e7527fb6dd225cd99b',1,'ordering.c']]]
];
