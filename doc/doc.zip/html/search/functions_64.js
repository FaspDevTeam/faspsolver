var searchData=
[
  ['dgetrf_5f',['dgetrf_',['../poisson__fdm_8h.html#ab6295bc6925ad53b3d276e260cff8204',1,'poisson_fdm.h']]],
  ['dispose_5felt',['dispose_elt',['../coarsening__rs_8c.html#a8828409140191924d87dbce3e4f42be4',1,'coarsening_rs.c']]],
  ['dswapping',['dSwapping',['../ordering_8c.html#afca6748aea4d52e7527fb6dd225cd99b',1,'ordering.c']]]
];
