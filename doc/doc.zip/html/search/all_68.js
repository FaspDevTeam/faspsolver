var searchData=
[
  ['head',['head',['../structlinked__list.html#ae8dfd1f02d32994edcee5f5ff0788ca5',1,'linked_list']]]
];
