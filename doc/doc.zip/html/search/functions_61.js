var searchData=
[
  ['aaxpby',['aAxpby',['../smoother__str_8c.html#ad76366bfd216f81659a607d39b036c56',1,'smoother_str.c']]],
  ['aggregation',['aggregation',['../amg__setup__aggregation_8inl.html#aa5d1546baca9d6ca3915389bf35ddd24',1,'amg_setup_aggregation.inl']]],
  ['amg_5fsetup_5fsmoothp_5fsmootha',['amg_setup_smoothP_smoothA',['../amg__setup__sa_8c.html#ab93488bc56a3230000fdea8b13c24a2b',1,'amg_setup_sa.c']]],
  ['amg_5fsetup_5fsmoothp_5funsmootha',['amg_setup_smoothP_unsmoothA',['../amg__setup__sa_8c.html#a04fcae8dd5f64a16a1b0412ee83db956',1,'amg_setup_sa.c']]],
  ['amg_5fsetup_5funsmoothp_5funsmootha',['amg_setup_unsmoothP_unsmoothA',['../amg__setup__ua_8c.html#a4f7a65da60a1e1cd04f623bd80a33129',1,'amg_setup_ua.c']]]
];
