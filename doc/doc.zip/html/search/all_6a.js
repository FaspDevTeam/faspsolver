var searchData=
[
  ['j',['J',['../structdCOOmat.html#a236f83c20ce278841fc8ef6e1aacb8e0',1,'dCOOmat::J()'],['../structiCOOmat.html#a236f83c20ce278841fc8ef6e1aacb8e0',1,'iCOOmat::J()']]],
  ['ja',['ja',['../structdCSRLmat.html#acd4cdbb6856b6bbc078b03702169fd2d',1,'dCSRLmat::ja()'],['../structdCSRmat.html#ab39d8b2fa3fbf92c115fa73cb98bc7ce',1,'dCSRmat::JA()'],['../structiCSRmat.html#ab39d8b2fa3fbf92c115fa73cb98bc7ce',1,'iCSRmat::JA()'],['../structdBSRmat.html#ab39d8b2fa3fbf92c115fa73cb98bc7ce',1,'dBSRmat::JA()']]],
  ['jacobi',['JACOBI',['../messages_8h.html#a757914ed6297a006d7fd30933340d009',1,'messages.h']]]
];
