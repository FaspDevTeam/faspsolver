var searchData=
[
  ['generate_5fs',['generate_S',['../coarsening__rs_8c.html#a336d97c8fa7a4f1a596ae5f0294138f4',1,'coarsening_rs.c']]],
  ['generate_5fs_5frs',['generate_S_rs',['../coarsening__rs_8c.html#abe4c9efe00b7ddf6fb749fedce78074a',1,'coarsening_rs.c']]],
  ['generate_5fsparsity_5fp',['generate_sparsity_P',['../coarsening__rs_8c.html#a4de486ec82a6c8a7a4eabca222704931',1,'coarsening_rs.c']]],
  ['generate_5fsparsity_5fp_5fomp',['generate_sparsity_P_omp',['../coarsening__rs__omp_8c.html#ac0d7fd8a97ad1b0160d6c9a474d1a50e',1,'coarsening_rs_omp.c']]],
  ['generate_5fsparsity_5fp_5fstandard',['generate_sparsity_P_standard',['../coarsening__rs_8c.html#a95710054b71cd572d1a837ab72cb85bf',1,'coarsening_rs.c']]],
  ['genintval',['genintval',['../interpolation_8c.html#afc2cb4b277290d876c8c29e6383b3d1f',1,'interpolation.c']]],
  ['gentisquare_5fnomass',['gentisquare_nomass',['../interpolation_8c.html#abdf2ac247c0da06d8427a64cfafc9cc0',1,'interpolation.c']]],
  ['get_5fblock',['get_block',['../interpolation_8c.html#a70a4b809343d988f2c49973da3b6d7f2',1,'interpolation.c']]],
  ['get_5fl2_5ferror_5fheat',['get_l2_error_heat',['../heat__fem_8c.html#a650afe3d59d8a44548975788247751b3',1,'heat_fem.c']]],
  ['getinonefull',['getinonefull',['../interpolation_8c.html#a61e82d59cdba4a3c75f5fc69374675c1',1,'interpolation.c']]],
  ['getiteval',['getiteval',['../interpolation_8c.html#adecc7496cb9018c50cbc94bc6b6e669e',1,'interpolation.c']]],
  ['gradbasisp1',['gradBasisP1',['../basis_8inl.html#a96c6848408346fb823f1509d63cd016b',1,'basis.inl']]],
  ['graphadd',['GraphAdd',['../coarsening__cr_8c.html#aa607cea61a0ded6ad9d52952fca43e48',1,'coarsening_cr.c']]],
  ['graphremove',['GraphRemove',['../coarsening__cr_8c.html#a0a78e970c9804d7cbdbe596691ef5bbb',1,'coarsening_cr.c']]]
];
