var searchData=
[
  ['nedmallinfo',['nedmallinfo',['../structnedmallinfo.html',1,'']]]
];
