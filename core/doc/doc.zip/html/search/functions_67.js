var searchData=
[
  ['generate_5fs',['generate_S',['../coarsening__rs_8c.html#a336d97c8fa7a4f1a596ae5f0294138f4',1,'coarsening_rs.c']]],
  ['generate_5fs_5frs',['generate_S_rs',['../coarsening__rs_8c.html#abe4c9efe00b7ddf6fb749fedce78074a',1,'coarsening_rs.c']]],
  ['generate_5fsparsity_5fp',['generate_sparsity_P',['../coarsening__rs_8c.html#a4de486ec82a6c8a7a4eabca222704931',1,'coarsening_rs.c']]],
  ['gentisquare_5fnomass',['gentisquare_nomass',['../interpolation_8c.html#abdf2ac247c0da06d8427a64cfafc9cc0',1,'interpolation.c']]],
  ['get_5fblock',['get_block',['../interpolation_8c.html#a70a4b809343d988f2c49973da3b6d7f2',1,'interpolation.c']]],
  ['getinonefull',['getinonefull',['../interpolation_8c.html#a61e82d59cdba4a3c75f5fc69374675c1',1,'interpolation.c']]],
  ['getiteval',['getiteval',['../interpolation_8c.html#adecc7496cb9018c50cbc94bc6b6e669e',1,'interpolation.c']]],
  ['graphadd',['GraphAdd',['../coarsening__cr_8c.html#aa607cea61a0ded6ad9d52952fca43e48',1,'coarsening_cr.c']]],
  ['graphremove',['GraphRemove',['../coarsening__cr_8c.html#a0a78e970c9804d7cbdbe596691ef5bbb',1,'coarsening_cr.c']]]
];
