var searchData=
[
  ['check_5fsolu',['check_solu',['../regression_8c.html#a805049d92147d18c25ca3c93994b3124',1,'regression.c']]],
  ['create_5felt',['create_elt',['../coarsening__rs_8c.html#a5df3ee474119e8016f8478f57dfac3f4',1,'coarsening_rs.c']]]
];
