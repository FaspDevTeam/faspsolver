var searchData=
[
  ['amg_5fsetup_5fsmoothp_5fsmootha',['amg_setup_smoothP_smoothA',['../amg__setup__sa_8c.html#ab93488bc56a3230000fdea8b13c24a2b',1,'amg_setup_sa.c']]],
  ['amg_5fsetup_5funsmoothp_5funsmootha',['amg_setup_unsmoothP_unsmoothA',['../amg__setup__ua_8c.html#a4f7a65da60a1e1cd04f623bd80a33129',1,'amg_setup_ua.c']]],
  ['assemble_5fstiffmat',['assemble_stiffmat',['../poisson__fem_8c.html#ad7e5e989f96b0a5a538139b2fbbd6d80',1,'poisson_fem.c']]]
];
