var searchData=
[
  ['amg_5fsetup_5fsmoothp_5fsmootha',['amg_setup_smoothP_smoothA',['../amg__setup__sa_8c.html#ab93488bc56a3230000fdea8b13c24a2b',1,'amg_setup_sa.c']]],
  ['amg_5fsetup_5funsmoothp_5funsmootha',['amg_setup_unsmoothP_unsmoothA',['../amg__setup__ua_8c.html#a4f7a65da60a1e1cd04f623bd80a33129',1,'amg_setup_ua.c']]],
  ['assemble',['assemble',['../test_8c.html#addf204fe7efcc035d7108e1316e299a5',1,'assemble(dCSRmat *ptr_A, dvector *ptr_b, int levelNum):&#160;assemble.c'],['../testfem_8c.html#addf204fe7efcc035d7108e1316e299a5',1,'assemble(dCSRmat *ptr_A, dvector *ptr_b, int levelNum):&#160;assemble.c'],['../testomp_8c.html#addf204fe7efcc035d7108e1316e299a5',1,'assemble(dCSRmat *ptr_A, dvector *ptr_b, int levelNum):&#160;assemble.c'],['../testrap_8c.html#addf204fe7efcc035d7108e1316e299a5',1,'assemble(dCSRmat *ptr_A, dvector *ptr_b, int levelNum):&#160;assemble.c'],['../assemble_8c.html#addf204fe7efcc035d7108e1316e299a5',1,'assemble(dCSRmat *ptr_A, dvector *ptr_b, int levelNum):&#160;assemble.c']]]
];
