var searchData=
[
  ['rb0b3d',['rb0b3d',['../smoother__omp_8c.html#adf02f33a9c86fb6e08fdc4a54f52f3fc',1,'rb0b3d(int *ia, int *ja, double *aa, double *u, double *f, int *mark, int nx, int ny, int nz, int nsweeps):&#160;smoother_omp.c'],['../fasp__functs_8h.html#a575e41b599d9dd45cf524ca29107096d',1,'rb0b3d(int *ia, int *ja, double *aa, double *u, double *f, int *mark, int nx, int ny, int nz, int nsweeps):&#160;smoother_omp.c']]],
  ['remove_5fpoint',['remove_point',['../coarsening__rs_8c.html#a3bcd228f24784d24d426f8d44de280cd',1,'coarsening_rs.c']]]
];
